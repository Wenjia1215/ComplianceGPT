"""Replay a bounded registry repair without changing frozen answer bodies."""

from __future__ import annotations

import argparse
import ast
import copy
import csv
import hashlib
import io
import json
import subprocess
import sys
import types
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

HERE = Path(__file__).resolve().parent
RESULT_ID = "clarification_registry_repair_v2"
REGISTRY_ID = "odp_registry_source_repair_v2"
COMMITS = {
    "repo_pin": "c4188bfb459210d16c8c43f7819df35ba4a6ee07",
    "repo_publication": "9116c4f9bf12042878d37935a036139f70529fd1",
}
ALLOWED_REGISTRY_FIELDS = {"friendly_label", "ask_prompt", "data_type", "examples", "cardinality"}
ALLOWED_REQUEST_FIELDS = ALLOWED_REGISTRY_FIELDS - {"examples"}
NATURAL_BASE = "experiments/external_validity/natural_questions_v2/results_v1"
BASE = "experiments/answerer_comparison"


def sha(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def file_sha(path: Path) -> str:
    return sha(path.read_bytes())


def canonical_sha(value: Any) -> str:
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n")


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n" for r in rows))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False, sort_keys=True) if isinstance(v, (dict, list)) else v
                             for k, v in row.items()})


def read_csv(text: str) -> dict[str, dict]:
    rows = list(csv.DictReader(io.StringIO(text.lstrip("\ufeff"))))
    result = {str(r["query_id"]): r for r in rows}
    if len(rows) != len(result):
        raise ValueError("Duplicate query IDs")
    return result


def differences(left: dict, right: dict) -> set[str]:
    return {k for k in set(left) | set(right) if k not in left or k not in right or left[k] != right[k]}


def verify_hash(path: Path, expected: str) -> None:
    if file_sha(path) != expected:
        raise ValueError(f"Frozen source changed: {path.name}")


def verify_sources(roots: dict[str, Path], specs: list[dict]) -> dict[str, str]:
    result = {}
    for spec in specs:
        key = spec["checkout"] + "/" + spec["path"]
        path = roots[spec["checkout"]] / spec["path"]
        verify_hash(path, spec["sha256"])
        result[key] = file_sha(path)
    return result


def patch_registry(original: dict, records: dict, repairs: list[dict], revision: str) -> tuple[dict, list[dict]]:
    revised = copy.deepcopy(original)
    deltas = []
    seen = set()
    for repair in repairs:
        if repair["revision"] != revision:
            continue
        pid = repair["param_id"]
        if pid in seen or pid not in original or pid not in records:
            raise ValueError("Missing or duplicate exact parameter identity")
        seen.add(pid)
        entry, definition = original[pid], records[pid]
        if entry.get("version") != revision or definition.get("kind") not in {"odp", "prm"}:
            raise ValueError("Repair does not match the active revision or a parameter definition")
        if canonical_sha(entry) != repair["original_entry_sha256"]:
            raise ValueError("Original registry entry changed")
        if canonical_sha(definition) != repair["canonical_definition_sha256"] or definition["text"] != repair["canonical_definition_text"]:
            raise ValueError("Canonical parameter definition changed")
        fields = repair["patch_fields"]
        if not fields or set(fields) - ALLOWED_REGISTRY_FIELDS or any(k not in entry for k in fields):
            raise ValueError("Repair changes fields outside the bounded metadata scope")
        if not str(fields.get("ask_prompt", "")).strip():
            raise ValueError("Repair lacks a clarification prompt")
        revised[pid].update(copy.deepcopy(fields))
        changed = differences(entry, revised[pid])
        if not changed or changed - ALLOWED_REGISTRY_FIELDS:
            raise ValueError("Invalid registry change")
        deltas.append({**repair, "changed_fields": sorted(changed), "before": entry, "after": revised[pid]})
    if set(revised) != set(original) or any(revised[pid] != original[pid] for pid in set(original) - seen):
        raise ValueError("Repair changes identifiers or unlisted entries")
    return revised, deltas


def guard_contract_change(before: dict, after: dict, allowed_ids: set[str]) -> list[dict]:
    if differences(before, after) - {"ask_list"}:
        raise ValueError("Repair changes a contract field beyond ask_list")
    old, new = before.get("ask_list", []), after.get("ask_list", [])
    if not isinstance(old, list) or not isinstance(new, list) or len(old) != len(new):
        raise ValueError("Repair changes request count or shape")
    identities = [a.get("param_id") for a in old]
    if len(set(identities)) != len(identities):
        raise ValueError("Duplicate request parameter IDs")
    changes = []
    for left, right in zip(old, new):
        if left.get("param_id") != right.get("param_id"):
            raise ValueError("Repair changes request order or identity")
        fields = differences(left, right)
        if fields and (left["param_id"] not in allowed_ids or fields - ALLOWED_REQUEST_FIELDS):
            raise ValueError("Repair changes unlisted requests or protected request fields")
        if fields:
            changes.append({"param_id": left["param_id"], "changed_fields": sorted(fields), "before": left, "after": right})
    return changes


def rebuild_requests(contract: dict, original_registry: dict, revised_registry: dict, builder, allowed_ids: set[str]) -> tuple[dict, list[dict]]:
    snapshot = canonical_sha(contract)
    old_requests = builder(copy.deepcopy(contract["odp_required_list"]), copy.deepcopy(contract["evidence_spans"]), copy.deepcopy(original_registry))
    if old_requests != contract.get("ask_list", []):
        raise ValueError("The original registry does not reproduce the frozen request list")
    revised = copy.deepcopy(contract)
    revised["ask_list"] = builder(copy.deepcopy(contract["odp_required_list"]), copy.deepcopy(contract["evidence_spans"]), copy.deepcopy(revised_registry))
    changes = guard_contract_change(contract, revised, allowed_ids)
    if canonical_sha(contract) != snapshot:
        raise ValueError("Request construction mutated the original contract")
    return revised, changes


def builder_source(payload: str) -> tuple[ast.FunctionDef, str]:
    nodes = [n for n in ast.parse(payload).body if isinstance(n, ast.FunctionDef) and n.name == "_build_ask_list"]
    if len(nodes) != 1:
        raise ValueError("Production request builder must occur exactly once")
    return nodes[0], ast.get_source_segment(payload, nodes[0])


def load_builder(payload: str, extractor, sentinel: str):
    node, source = builder_source(payload)
    namespace = {"Any": Any, "Dict": Dict, "List": List, "_extract_odp_ids": extractor,
                 "_ASSIGNMENT_REQUIRED_SENTINEL": sentinel}
    module = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
    exec(compile(module, "frozen_production_request_builder", "exec"), namespace)
    return namespace["_build_ask_list"], sha(source.encode())


def validate_case(case: dict, contract: dict, records: dict) -> None:
    pid = case["param_id"]
    if pid not in records or records[pid]["text"] != case["canonical_definition"]["text"]:
        raise ValueError("Case definition is not canonical")
    asks = [a for a in contract["ask_list"] if a["param_id"] == pid]
    if asks != [case["original_request"]]:
        raise ValueError("Case request is not the original returned request")
    spans = {s["source_id"]: s["span_text"] for s in contract["evidence_spans"]}
    sources = case["original_request"].get("source_ids", [])
    if not sources:
        raise ValueError("Case lacks a cited source")
    for sid in sources:
        if sid not in spans or sid not in records or pid not in spans[sid] or spans[sid] != records[sid]["text"]:
            raise ValueError("Case source is missing, noncanonical, or lacks the exact parameter")


def csv_registry(original_text: str, registry: dict, repairs: list[dict], revision: str) -> list[dict]:
    rows = list(csv.DictReader(io.StringIO(original_text.lstrip("\ufeff"))))
    ids = [r["param_id"] for r in rows]
    # Rev. 5 has several clause-association rows for the same parameter.
    # Preserve those rows and update each occurrence; JSON has one merged entry.
    if set(ids) != set(registry):
        raise ValueError("CSV and JSON registry identities differ")
    scopes = {r["param_id"]: set(r["patch_fields"]) for r in repairs if r["revision"] == revision}
    revised = copy.deepcopy(rows)
    for before, row in zip(rows, revised):
        pid = row["param_id"]
        for field in scopes.get(pid, set()):
            value = registry[pid][field]
            row[field] = " | ".join(value) if field == "examples" else value
        if differences(before, row) - scopes.get(pid, set()):
            raise ValueError("CSV repair exceeded its field scope")
        for field in scopes.get(pid, set()):
            expected = registry[pid][field]
            actual = [x.strip() for x in row[field].split("|") if x.strip()] if field == "examples" else row[field]
            if actual != expected:
                raise ValueError("Revised CSV and JSON metadata differ")
    return revised


def assessment_without_identity(value: dict) -> dict:
    return {k: v for k, v in value.items() if k != "review_id"}


def run(roots: dict[str, Path], batch2: Path, output: Path) -> dict:
    output = output.resolve()
    roots = {k: p.resolve() for k, p in roots.items()}
    for root in roots.values():
        if output == root or root in output.parents:
            raise ValueError("Write repaired artifacts outside frozen source checkouts")
    if output.exists() and any(output.iterdir()):
        raise ValueError("The new output directory must be empty")
    config = json.loads((HERE / "RUN_CONFIG.json").read_text())
    if config["source_commits"] != COMMITS or config["result_id"] != RESULT_ID or config["registry_id"] != REGISTRY_ID:
        raise ValueError("Unexpected repair identity or source commits")
    for name, root in roots.items():
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
        if head != COMMITS[name]:
            raise ValueError("Wrong frozen source commit")
    statuses = {name: subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True) for name, root in roots.items()}
    if any(statuses.values()):
        raise ValueError("Frozen source checkouts must be clean")
    for path, key in ((HERE / "PROTOCOL.txt", "protocol_sha256"), (HERE / "inputs/repairs.json", "repairs_sha256"),
                      (HERE / "inputs/baseline_manifest.json", "baseline_manifest_sha256"), (batch2 / "manifest.json", "batch2_manifest_sha256")):
        verify_hash(path, config[key])
    before_hashes = verify_sources(roots, config["verified_source_inputs"])
    parent_manifest = json.loads((batch2 / "manifest.json").read_text())
    for rel, wanted in parent_manifest["output_sha256"].items():
        verify_hash(batch2 / rel, wanted)
    sys.path[:0] = [str(roots["repo_pin"]), str(roots["repo_pin"] / "src")]
    from answerer_comparison import strict_pass as scoring
    from compliancegpt.pipeline.odp_policy import extract_odp_ids, ASSIGNMENT_REQUIRED_SENTINEL
    from experiments.answerer_comparison.run_strict_pass import load_inputs
    if scoring.RULE_VERSION != config["endpoint"]:
        raise ValueError("Wrong strict-pass endpoint")
    inputs, main_hashes = load_inputs(roots["repo_pin"])
    baseline = json.loads((HERE / "inputs/baseline_manifest.json").read_text())
    if main_hashes != baseline["main_input_sha256"]:
        raise ValueError("Benchmark inputs differ from Batch 1")
    reviews = scoring.load_reviews(roots["repo_pin"] / BASE / "strict_pass_reviews.jsonl")
    builder_text = (roots["repo_pin"] / "src/compliancegpt/pipeline/pipeline.py").read_text()
    builder, builder_hash = load_builder(builder_text, extract_odp_ids, ASSIGNMENT_REQUIRED_SENTINEL)
    publication_text = (roots["repo_publication"] / "src/compliancegpt/pipeline/pipeline.py").read_text()
    if builder_source(builder_text)[1] != builder_source(publication_text)[1]:
        raise ValueError("The request builder differs between source pins")
    repairs = json.loads((HERE / "inputs/repairs.json").read_text())
    repair_map = {(r["revision"], r["param_id"]): r for r in repairs}
    if len(repair_map) != len(repairs) or Counter(r["revision"] for r in repairs) != Counter(config["expected_repairs"]):
        raise ValueError("The repair set differs from the bounded protocol")
    registries, revised_registries, deltas, registry_csv = {}, {}, [], {}
    for revision, (records, _, _) in inputs.items():
        rel = f"data/ODP/{revision}/odp_registry_{revision}.json"
        if (roots["repo_pin"] / rel).read_bytes() != (roots["repo_publication"] / rel).read_bytes():
            raise ValueError("Original registry differs across source pins")
        registries[revision] = json.loads((roots["repo_pin"] / rel).read_text())
        revised_registries[revision], local = patch_registry(registries[revision], records, repairs, revision)
        deltas.extend(local)
        rel_csv = f"data/ODP/{revision}/odp_registry_{revision}.csv"
        registry_csv[revision] = csv_registry((roots["repo_pin"] / rel_csv).read_text(), revised_registries[revision], repairs, revision)
    repaired_hashes = {rev: canonical_sha(x) for rev, x in revised_registries.items()}
    cases, request_changes, contract_changes, replay_contracts, score_rows, runtime_rows = [], [], [], [], [], []
    summary_rows = []
    saved_parent_scores = {(r["revision"], r["query_id"]): r for r in map(json.loads, (batch2 / "strict_pass_rows.jsonl").read_text().splitlines())
                           if r["condition"] == "no_selector_requests"}
    all_contracts = {}

    def process(revision: str, condition: str, rows: dict, frozen_scores: dict | None = None, historical_verifier=None) -> None:
        records, gold, _ = inputs[revision]
        allowed_ids = {pid for rev, pid in repair_map if rev == revision}
        changed_count = 0
        pass_before = pass_after = None
        if frozen_scores is not None:
            pass_before = pass_after = 0
        for qid in sorted(rows, key=lambda x: int(x.removeprefix("NQ"))):
            row = rows[qid]
            original = json.loads(row["contract_json"])
            after, changes = rebuild_requests(original, registries[revision], revised_registries[revision], builder, allowed_ids)
            changed_count += bool(changes)
            non_request_hash = canonical_sha({k: v for k, v in original.items() if k != "ask_list"})
            key = (condition, revision, qid)
            all_contracts[key] = original
            wrapper = {"result_id": RESULT_ID, "registry_id": REGISTRY_ID, "condition": condition, "revision": revision,
                       "query_id": qid, "context_sha256": row["context_sha256"], "evidence_window_sha256": row["evidence_window_sha256"],
                       "before_contract_sha256": canonical_sha(original), "after_contract_sha256": canonical_sha(after),
                       "unchanged_non_request_fields_sha256": non_request_hash, "changed_fields": ["ask_list"] if changes else [],
                       "changed_request_count": len(changes)}
            contract_changes.append(wrapper)
            replay_contracts.append({**wrapper, "contract": after})
            for change in changes:
                request_changes.append({**wrapper, **change})
            if frozen_scores is not None:
                scores = []
                for contract in (original, after):
                    scores.append(scoring.evaluate_contract(revision=revision, query_id=qid, contract=contract, gold=gold[qid],
                                  records=records, window_ids=row["evidence_window_source_ids"].split("|"), reviews=reviews))
                before, revised = scores
                if any(before[k] != frozen_scores[qid][k] for k in before):
                    raise ValueError(f"Frozen strict assessment does not reproduce: {condition}/{revision}/{qid}")
                if assessment_without_identity(before) != assessment_without_identity(revised):
                    raise ValueError("Registry repair changes a strict-pass gate or decision")
                pass_before += before["strict_pass"]
                pass_after += revised["strict_pass"]
                score_rows.append({**wrapper, "before": before, "after": revised})
            elif historical_verifier is not None:
                corpus = {k: r["text"] for k, r in records.items()}
                before = historical_verifier(original, corpus=corpus, org_profile={}, strict_verbatim=True, corpus_version=revision)
                revised = historical_verifier(after, corpus=corpus, org_profile={}, strict_verbatim=True, corpus_version=revision)
                if before != revised or before[0] != (row["contract_validity_pass"].lower() == "true"):
                    raise ValueError("Historical public-question validity does not reproduce or changes")
                runtime_rows.append({**wrapper, "before_runtime_valid": before[0], "after_runtime_valid": revised[0], "errors": before[1],
                                     "benchmark_strict_pass": None, "reason": "Separate public-question protocol; no benchmark score assigned"})
            case_group = "natural_questions" if condition == "natural_questions" else "benchmark"
            selected = config["selected_case_questions"].get(case_group, {}).get(revision, [])
            if condition != "no_selector_requests" and qid in selected:
                for change in changes:
                    repair = repair_map[(revision, change["param_id"])]
                    case = {"case_id": f"{condition}:{revision}:{qid}:{change['param_id']}", "condition": condition, "revision": revision,
                            "query_id": qid, "question": original["question"], "param_id": change["param_id"],
                            "issue_kind": repair["issue_kind"], "reason": repair["reason"], "selection_scope": repair["selection_scope"],
                            "original_request": change["before"], "revised_request": change["after"],
                            "canonical_definition": records[change["param_id"]],
                            "canonical_definition_sha256": canonical_sha(records[change["param_id"]]),
                            "canonical_sources": [records[sid] for sid in change["before"]["source_ids"]],
                            "original_contract_sha256": canonical_sha(original), "strict_pass_v1_before": before["strict_pass"] if frozen_scores is not None else None,
                            "strict_pass_v1_after": revised["strict_pass"] if frozen_scores is not None else None,
                            "assessment_scope": "Selected source-to-request case; no registry-wide quality rate or independent approval"}
                    validate_case(case, original, records)
                    cases.append(case)
        summary_rows.append({"revision": revision, "condition": condition, "contracts": len(rows), "contracts_with_changed_requests": changed_count,
                             "strict_pass_before": pass_before, "strict_pass_after": pass_after,
                             "changed_request_records": sum(r["changed_request_count"] for r in contract_changes if r["revision"] == revision and r["condition"] == condition)})

    for revision, (_, _, systems) in inputs.items():
        folder = "rq2_frontier_baseline_rev5" if revision == "rev5" else "rq2_frontier_baseline"
        original_scores = {r["query_id"]: r for r in map(json.loads, (roots["repo_pin"] / BASE / folder / "results_v1/strict_pass_rows.jsonl").read_text().splitlines())
                           if r["system"] == "compliancegpt_4bit"}
        process(revision, "main_selector", systems["compliancegpt"], original_scores)
        parent_rows = read_csv((batch2 / f"contracts/{revision}_no_selector_requests.csv").read_text())
        process(revision, "no_selector_requests", parent_rows,
                {qid: r for (rev, qid), r in saved_parent_scores.items() if rev == revision})
    archive = roots["repo_publication"] / NATURAL_BASE / "natural_questions_v2_results.zip"
    with zipfile.ZipFile(archive) as bundle:
        code_rel = "src/compliancegpt/generator/verifier/verifier.py"
        code = bundle.read("source_snapshot/" + code_rel)
        archive_config = json.loads(bundle.read("run_config.json"))
        if sha(code) != archive_config["signature"]["code_sha256"][code_rel]:
            raise ValueError("Historical verifier code does not match its run signature")
        module = types.ModuleType("historical_natural_questions_verifier")
        module.__file__ = "natural_questions_v2_results.zip:source_snapshot/" + code_rel
        sys.modules[module.__name__] = module
        exec(compile(code.decode(), module.__file__, "exec"), module.__dict__)
        historical_verifier_hash = sha(code)
        archived_builder = bundle.read("source_snapshot/src/compliancegpt/pipeline/pipeline.py").decode()
        if builder_source(archived_builder)[1] != builder_source(builder_text)[1]:
            raise ValueError("Historical archive uses a different request builder")
        member_hashes = {}
        for revision in ("rev4", "rev5"):
            member = f"contracts/{revision}_compliancegpt.csv"
            payload = bundle.read(member)
            member_hashes[member] = sha(payload)
            rows = read_csv(payload.decode("utf-8-sig"))
            process(revision, "natural_questions", rows, historical_verifier=module.verify_contract_validity)
    archived_audit = json.loads((roots["repo_publication"] / NATURAL_BASE / "CLARIFICATION_AUDIT.json").read_text())
    for instance in archived_audit["instances"]:
        original = all_contracts[("natural_questions", instance["revision"], instance["query_id"])]
        ask = next(a for a in original["ask_list"] if a["param_id"] == instance["param_id"])
        if any(ask.get(k) != instance.get(k) for k in ("ask_prompt", "data_type", "cardinality", "source_ids", "raw_marker", "friendly_label")):
            raise ValueError("Archived clarification audit does not match the original request")
    if len(cases) != 20 or {(c["revision"], c["param_id"]) for c in cases} != set(repair_map):
        raise ValueError("Every repaired entry must have its expected source-backed case")
    after_hashes = verify_sources(roots, config["verified_source_inputs"])
    if before_hashes != after_hashes or any(canonical_sha(revised_registries[rev]) != h for rev, h in repaired_hashes.items()):
        raise ValueError("Frozen sources or revised registries changed during replay")
    if {name: subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True) for name, root in roots.items()} != statuses:
        raise ValueError("The replay modified a source checkout")
    output.mkdir(parents=True, exist_ok=True)
    for revision, registry in revised_registries.items():
        write_json(output / f"registry_v2/{revision}/odp_registry_{revision}.json", registry)
        write_csv(output / f"registry_v2/{revision}/odp_registry_{revision}.csv", registry_csv[revision])
    write_json(output / "registry_patch.json", deltas)
    write_jsonl(output / "case_ledger.jsonl", cases)
    write_csv(output / "case_table.csv", [{"case_id": c["case_id"], "revision": c["revision"], "query_id": c["query_id"], "param_id": c["param_id"],
              "issue_kind": c["issue_kind"], "canonical_definition": c["canonical_definition"]["text"], "original_prompt": c["original_request"]["ask_prompt"],
              "original_type": c["original_request"]["data_type"], "revised_prompt": c["revised_request"]["ask_prompt"],
              "revised_type": c["revised_request"]["data_type"], "strict_pass_v1_before": c["strict_pass_v1_before"], "strict_pass_v1_after": c["strict_pass_v1_after"]} for c in cases])
    write_jsonl(output / "replay_contracts.jsonl", replay_contracts)
    write_jsonl(output / "request_changes.jsonl", request_changes)
    write_jsonl(output / "contract_changes.jsonl", contract_changes)
    write_jsonl(output / "benchmark_assessments.jsonl", score_rows)
    write_jsonl(output / "natural_runtime_checks.jsonl", runtime_rows)
    write_csv(output / "comparison_table.csv", summary_rows)
    summary = {"result_id": RESULT_ID, "registry_id": REGISTRY_ID, "endpoint": scoring.RULE_VERSION,
               "study_type": config["study_type"], "new_model_calls": 0, "registry_entries_repaired": len(deltas),
               "selected_case_instances": len(cases), "selected_case_questions": 9, "replayed_contracts": len(replay_contracts),
               "benchmark_assessments": 2 * len(score_rows), "natural_runtime_assessments": 2 * len(runtime_rows),
               "new_semantic_review_records": 0, "contracts_with_changed_requests": sum(bool(r["changed_fields"]) for r in contract_changes),
               "changed_request_records": len(request_changes), "comparisons": summary_rows,
               "strict_pass_decisions_and_gates_unchanged": True, "source_hashes_unchanged": True,
               "all_checks_passed": True, "original_clarification_audit_instances_verified": len(archived_audit["instances"]),
               "boundary": "Selected cases do not establish an error rate, parameter necessity, whole-question usefulness, or organizational approval"}
    write_json(output / "summary.json", summary)
    write_json(output / "registry_v2/REGISTRY_MANIFEST.json", {"registry_id": REGISTRY_ID, "parent_registries": {rev: file_sha(roots["repo_pin"] / f"data/ODP/{rev}/odp_registry_{rev}.json") for rev in revised_registries},
               "source_commit": COMMITS["repo_pin"], "repairs": config["expected_repairs"], "allowed_fields": sorted(ALLOWED_REGISTRY_FIELDS),
               "use": "Explicit opt-in for a new run; preserve historical defaults and results", "types_and_cardinality": "Descriptive request metadata; no supplied-value validator or organization approval is added"})
    manifest = {"result_id": RESULT_ID, "source_commits": COMMITS, "verified_source_sha256": before_hashes,
                "main_input_sha256": main_hashes, "config_sha256": file_sha(HERE / "RUN_CONFIG.json"),
                "protocol_sha256": file_sha(HERE / "PROTOCOL.txt"), "script_sha256": file_sha(Path(__file__)),
                "repair_specification_sha256": file_sha(HERE / "inputs/repairs.json"), "batch2_manifest_sha256": file_sha(batch2 / "manifest.json"),
                "production_builder_function_sha256": builder_hash, "historical_verifier_sha256": historical_verifier_hash,
                "natural_archive_contract_members_sha256": member_hashes,
                "original_output_paths_written": [], "verified_source_checkouts_clean": True,
                "output_sha256": {p.relative_to(output).as_posix(): file_sha(p) for p in sorted(output.rglob("*")) if p.is_file()}}
    write_json(output / "manifest.json", manifest)
    print(json.dumps(summary, sort_keys=True))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--publication-root", type=Path, required=True)
    parser.add_argument("--batch2-results", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    run({"repo_pin": args.repo_root, "repo_publication": args.publication_root}, args.batch2_results, args.output_dir)


if __name__ == "__main__":
    main()
