Batch 3: clarification cases and registry repair

The package contains a separate source-backed registry version, a twenty-instance
case ledger, and a deterministic replay of the affected request metadata. It
preserves the original benchmark, public-question archive, and Batch 2 results.

Run from the workspace root, with the original pinned checkouts available:

python3 -m unittest discover -s revision/studies/clarification_registry_repair_v2/tests -v

python3 revision/studies/clarification_registry_repair_v2/run_repair.py \
  --repo-root audit/repo_pin \
  --publication-root audit/repo_publication \
  --batch2-results revision/studies/rq2_no_selector_requests_v1/results_v1 \
  --output-dir revision/studies/clarification_registry_repair_v2/reproduction_v2

Choose a new empty output directory for each reproduction. The script rejects
writes inside frozen source checkouts and rejects nonempty output destinations.
It verifies source commits, original input hashes, and the Batch 2 output manifest.

Read BATCH_03_FINDINGS.txt for the result and its limits. Read PROTOCOL.txt for
the repair scope. The case table provides short comparisons; the JSONL ledger
retains exact requests, source definitions, cited clauses, and contract hashes.

The new registry files live in results_v1/registry_v2/. Their identity appears in
REGISTRY_MANIFEST.json rather than in the individual revision fields. Rev. 4 and
Rev. 5 remain distinct catalogs. Future runs should select the new registry
explicitly and record its hash; historical runs should retain their original one.

The replacement metadata guides requests. It does not validate supplied values,
grant approval, add bindings, recover missing evidence, or add nested obligations.
Strict-pass-v1 remains the frozen benchmark endpoint. Its answer-body certificates
do not certify clarification value domains or question-level parameter necessity.
