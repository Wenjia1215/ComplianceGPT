"""Reject edits that would contaminate the frozen comparison."""

import copy
import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
WORKSPACE = HERE.parents[2]
REPO = WORKSPACE / "audit/repo_pin"
sys.path.insert(0, str(HERE))
import run_repair as repair


class RepairBoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = json.loads((REPO / "data/ODP/rev5/odp_registry_rev5.json").read_text())
        cls.records = {r["id"]: r for r in map(json.loads, (REPO / "data/ccs/nist800-53/NIST_SP-800-53_rev5_catalog.jsonl").read_text().splitlines())}
        cls.specs = json.loads((HERE / "inputs/repairs.json").read_text())
        path = REPO / "experiments/answerer_comparison/rq2_frontier_baseline_rev5/results_v1/references/rev5_compliancegpt_4bit.csv"
        with path.open(newline="") as handle:
            rows = {r["query_id"]: r for r in csv.DictReader(handle)}
        cls.row = rows["11"]
        cls.contract = json.loads(cls.row["contract_json"])
        sys.path[:0] = [str(REPO), str(REPO / "src")]
        from compliancegpt.pipeline.odp_policy import extract_odp_ids, ASSIGNMENT_REQUIRED_SENTINEL
        cls.builder, _ = repair.load_builder((REPO / "src/compliancegpt/pipeline/pipeline.py").read_text(), extract_odp_ids, ASSIGNMENT_REQUIRED_SENTINEL)
        cls.builder = staticmethod(cls.builder)

    def test_rejects_answer_evidence_state_and_debug_edits(self):
        for field, value in (("answer_text", "changed body"), ("evidence_spans", []), ("status", "OK"),
                             ("framework_version", "rev4"), ("odp_required_list", []), ("debug", {"changed": True})):
            with self.subTest(field=field):
                after = copy.deepcopy(self.contract)
                after[field] = value
                with self.assertRaises(ValueError):
                    repair.guard_contract_change(self.contract, after, set(self.registry))

    def test_rejects_request_identity_source_and_count_edits(self):
        for field, value in (("param_id", "different_parameter"), ("raw_marker", "different marker"), ("source_ids", [])):
            with self.subTest(field=field):
                after = copy.deepcopy(self.contract)
                after["ask_list"][0][field] = value
                with self.assertRaises(ValueError):
                    repair.guard_contract_change(self.contract, after, set(self.registry))
        for change in (lambda asks: asks.reverse(), lambda asks: asks.pop(), lambda asks: asks.append(copy.deepcopy(asks[0]))):
            after = copy.deepcopy(self.contract)
            change(after["ask_list"])
            with self.assertRaises(ValueError):
                repair.guard_contract_change(self.contract, after, set(self.registry))

    def test_rejects_unlisted_registry_and_request_changes(self):
        spec = copy.deepcopy(next(s for s in self.specs if s["param_id"] == "au-02_odp.01"))
        spec["patch_fields"]["raw_marker"] = "changed marker"
        with self.assertRaises(ValueError):
            repair.patch_registry(self.registry, self.records, [spec], "rev5")
        after = copy.deepcopy(self.contract)
        after["ask_list"][0]["ask_prompt"] = "edited"
        with self.assertRaises(ValueError):
            repair.guard_contract_change(self.contract, after, set())

    def test_rejects_source_definition_and_registry_drift(self):
        spec = next(s for s in self.specs if s["param_id"] == "au-02_odp.01")
        original = copy.deepcopy(self.registry)
        original[spec["param_id"]]["ask_prompt"] = "unrecorded prior edit"
        with self.assertRaises(ValueError):
            repair.patch_registry(original, self.records, [spec], "rev5")
        records = copy.deepcopy(self.records)
        records[spec["param_id"]]["text"] = "unrecorded source change"
        with self.assertRaises(ValueError):
            repair.patch_registry(self.registry, records, [spec], "rev5")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "input.json"
            path.write_text("changed bytes")
            with self.assertRaises(ValueError):
                repair.verify_hash(path, "0" * 64)

    def test_rejects_duplicate_parameter_repairs_and_wrong_revision(self):
        spec = next(s for s in self.specs if s["param_id"] == "au-02_odp.01")
        with self.assertRaises(ValueError):
            repair.patch_registry(self.registry, self.records, [spec, spec], "rev5")
        registry = copy.deepcopy(self.registry)
        registry[spec["param_id"]]["version"] = "rev4"
        with self.assertRaises(ValueError):
            repair.patch_registry(registry, self.records, [spec], "rev5")

    def test_rejects_unreproduced_original_requests(self):
        contract = copy.deepcopy(self.contract)
        contract["ask_list"][0]["ask_prompt"] = "unrecorded historical prompt"
        with self.assertRaises(ValueError):
            repair.rebuild_requests(contract, self.registry, self.registry, self.builder, set(self.registry))

    def test_preserves_csv_clause_associations_for_repeated_parameters(self):
        text = (REPO / "data/ODP/rev5/odp_registry_rev5.csv").read_text()
        original = list(csv.DictReader(text.splitlines()))
        revised, _ = repair.patch_registry(self.registry, self.records, self.specs, "rev5")
        rows = repair.csv_registry(text, revised, self.specs, "rev5")
        self.assertGreater(len(rows), len(revised))
        self.assertEqual([(r["param_id"], r["clause_id"]) for r in original],
                         [(r["param_id"], r["clause_id"]) for r in rows])
        repaired = [r for r in rows if r["param_id"] == "au-02_odp.01"]
        self.assertGreater(len(repaired), 1)
        self.assertEqual({r["ask_prompt"] for r in repaired}, {revised["au-02_odp.01"]["ask_prompt"]})

    def test_case_requires_actual_canonical_sources(self):
        pid = self.contract["ask_list"][0]["param_id"]
        case = {"param_id": pid, "original_request": copy.deepcopy(self.contract["ask_list"][0]),
                "canonical_definition": self.records[pid]}
        repair.validate_case(case, self.contract, self.records)
        case["original_request"]["source_ids"] = ["nonexistent_source"]
        with self.assertRaises(ValueError):
            repair.validate_case(case, self.contract, self.records)

    def test_real_q11_wrong_domain_passes_the_frozen_endpoint(self):
        from answerer_comparison import strict_pass as scoring
        gold_path = REPO / "data/gold_standard_datasets/nist800-53/nist_sp800-53_rev5_gold-set_100q.csv"
        with gold_path.open(newline="", encoding="utf-8-sig") as handle:
            gold = next(r for r in csv.DictReader(handle) if r["id"] == "11")
        self.assertIn("org units", self.contract["ask_list"][0]["ask_prompt"])
        result = scoring.evaluate_contract(revision="rev5", query_id="11", contract=self.contract, gold=gold,
                    records=self.records, window_ids=self.row["evidence_window_source_ids"].split("|"), reviews={})
        self.assertTrue(result["strict_pass"])
        self.assertEqual(result["review_method"], "full_retention_certificate")


if __name__ == "__main__":
    unittest.main()
