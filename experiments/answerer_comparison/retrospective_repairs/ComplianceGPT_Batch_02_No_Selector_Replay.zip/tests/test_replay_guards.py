"""Check the single-field replay boundary and frozen-input safeguards."""

import copy
import importlib.util
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "run_replay.py"
spec = importlib.util.spec_from_file_location("no_selector_replay", SCRIPT)
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)


class ReplayBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.original = {
            "question": "Who receives the notification?", "framework_version": "rev5",
            "answer_text": "Notify {{ insert: param, ac-02_odp.05 }}.",
            "evidence_spans": [{"source_id": "ac-2_smt.h", "span_text": "Notify {{ insert: param, ac-02_odp.05 }}."}],
            "status": "PARAMS_REQUIRED", "odp_required_list": ["ac-02_odp.05"], "ask_list": [],
            "debug": {"result_id": "rq2_no_selector_v1"},
        }

    def test_builder_cannot_change_body_status_sources_or_history(self):
        for field, value in (("answer_text", "Different requirement"), ("status", "OK"),
                             ("framework_version", "rev4"), ("evidence_spans", []),
                             ("odp_required_list", []), ("debug", {})):
            with self.subTest(field=field):
                changed = copy.deepcopy(self.original)
                changed[field] = value
                with self.assertRaisesRegex(ValueError, "beyond ask_list"):
                    replay.assert_request_only(self.original, changed)

    def test_builder_input_mutation_is_rejected_without_mutating_parent(self):
        parent = copy.deepcopy(self.original)

        def bad_builder(parameters, spans, registry):
            spans[0]["span_text"] = "A substituted organizational value"
            return []

        with self.assertRaisesRegex(ValueError, "beyond ask_list"):
            replay.construct_requests(parent, {}, bad_builder)
        self.assertEqual(parent, self.original)

    def test_already_modified_parent_is_rejected(self):
        changed = copy.deepcopy(self.original)
        changed["ask_list"] = [{"param_id": "ac-02_odp.05"}]
        with self.assertRaisesRegex(ValueError, "empty ask_list"):
            replay.construct_requests(changed, {}, lambda *_: [])

    def test_incomplete_or_reordered_window_is_rejected(self):
        row = {"query_id": "1", "context_sha256": "context", "evidence_window_sha256": "window"}
        matched = {**row, "evidence_window_source_ids": "ac-2_smt.h|ac-2_smt.h.1"}
        with self.assertRaisesRegex(ValueError, "complete ordered window"):
            replay.validate_window(self.original, row, matched)
        full = copy.deepcopy(self.original)
        full["evidence_spans"].append({"source_id": "ac-2_smt.h.1", "span_text": "Second clause"})
        full["evidence_spans"].reverse()
        with self.assertRaisesRegex(ValueError, "complete ordered window"):
            replay.validate_window(full, row, matched)

    def test_window_identity_drift_is_rejected(self):
        row = {"query_id": "1", "context_sha256": "original", "evidence_window_sha256": "window"}
        matched = {**row, "context_sha256": "changed", "evidence_window_source_ids": "ac-2_smt.h"}
        with self.assertRaisesRegex(ValueError, "window identity differs"):
            replay.validate_window(self.original, row, matched)

    def test_registry_or_source_hash_drift_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "registry.json"
            path.write_text('{"parameter": "original prompt"}')
            expected = {"registry.json": replay.file_digest(path)}
            path.write_text('{"parameter": "corrected prompt"}')
            with self.assertRaisesRegex(ValueError, "hash changed"):
                replay.verify_sources(root, expected)


if __name__ == "__main__":
    unittest.main()
