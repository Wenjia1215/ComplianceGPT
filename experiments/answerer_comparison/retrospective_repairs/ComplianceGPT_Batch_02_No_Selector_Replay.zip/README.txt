NO-SELECTOR REQUEST-CONSTRUCTION REPLAY

This package records Batch 2 of the dissertation patch. It contains the replay, its outputs, the protocol, and the validation record.
The new result identity is rq2_no_selector_requests_v1. The original rq2_no_selector_v1 contracts retain their historical identity.

REPRODUCE

Use the dissertation's pinned evaluation checkout:

git clone https://github.com/Wenjia1215/ComplianceGPT.git ComplianceGPT
git -C ComplianceGPT checkout --detach c4188bfb459210d16c8c43f7819df35ba4a6ee07

From this package's root, run the boundary tests:

python3 -m unittest discover -s tests -v

Run the replay into a new, empty destination:

python3 run_replay.py --repo-root /absolute/path/to/ComplianceGPT --output-dir /absolute/path/to/new_replay_results

The script checks the frozen inputs and code against the recorded baseline. It loads the original evaluator and request builder without model inference.
Use the pinned evaluation checkout rather than a later implementation. Registry repairs and revised scoring rules belong to separately identified analyses.

RESULT FILES

results_v1/summary.json contains all three configurations, output-size distributions, and paired outcomes for each revision.
results_v1/comparison_table.csv gives the compact main comparison. results_v1/per_question_comparison.csv gives each question's outcomes and burden measures.
results_v1/replay_contracts.jsonl stores the new contracts with parent hashes, window identities, and an outer replay identity.
results_v1/contract_changes.jsonl proves the single-field boundary. Historical debug metadata stays inside each contract because the replay leaves every non-request field unchanged.
results_v1/strict_pass_rows.jsonl and .csv record the gates for the selector, original no-selector, and request-constructed conditions.
results_v1/remaining_failures.jsonl records the nine remaining revision/question failures. It distinguishes failed contract checks from later semantic assessment.
results_v1/manifest.json hashes the inputs, code, protocol, and generated outputs. results_v1/validation.json records the replay's integrity checks.
INDEPENDENT_VALIDATION.json records the serialized-contract readback and the independent paired-statistic cross-check. Six boundary tests passed.
BATCH_02_FINDINGS.txt explains the results and their limits. workflow_status.json records the next editing batch.

ASSESSMENT BOUNDARY

This replay uses strict-pass-v1 and the original registries. It does not certify clarification meaning, question-level parameter necessity, or professional acceptance.
Answer and prompt lengths describe output size. Gold-relative precision measures identifier agreement, and additional identifiers have not all been judged irrelevant.
The comparison remains retrospective and uses frozen author labels. It adds request records to existing outputs rather than generating new answers or collecting new questions.
