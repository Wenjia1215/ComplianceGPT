"""Construct missing requests on copies of frozen no-selector contracts."""

from __future__ import annotations

import argparse
import ast
import copy
import csv
import hashlib
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

RESULT_ID = "rq2_no_selector_requests_v1"
PARENT_RESULT_ID = "rq2_no_selector_v1"
SOURCE_COMMIT = "c4188bfb459210d16c8c43f7819df35ba4a6ee07"
BASE = "experiments/answerer_comparison"
HERE = Path(__file__).resolve().parent


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def file_digest(path: Path) -> str:
    return digest(path.read_bytes())


def canonical_digest(value: Any) -> str:
    return digest(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n")


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n" for r in rows))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, ensure_ascii=False, sort_keys=True) if isinstance(value, (dict, list)) else value
                             for key, value in row.items()})


def read_rows(path: Path) -> dict[str, dict]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    result = {r["query_id"]: r for r in rows}
    if len(result) != len(rows):
        raise ValueError(f"Duplicate question IDs in {path.name}")
    return result


def verify_sources(repo_root: Path, expected: dict[str, str]) -> dict[str, str]:
    actual = {}
    for relative, wanted in sorted(expected.items()):
        path = repo_root / relative
        if not path.is_file():
            raise ValueError(f"Missing frozen source: {relative}")
        actual[relative] = file_digest(path)
        if actual[relative] != wanted:
            raise ValueError(f"Frozen source hash changed: {relative}")
    return actual


def changed_fields(original: dict, replay: dict) -> list[str]:
    return sorted(key for key in set(original) | set(replay)
                  if key not in original or key not in replay or original[key] != replay[key])


def assert_request_only(original: dict, replay: dict) -> list[str]:
    changes = changed_fields(original, replay)
    if any(key != "ask_list" for key in changes):
        raise ValueError(f"Replay changed fields beyond ask_list: {changes}")
    return changes


def construct_requests(original: dict, registry: dict, builder) -> dict:
    if original.get("ask_list") != []:
        raise ValueError("The parent no-selector contract must have an empty ask_list")
    replay = copy.deepcopy(original)
    replay["ask_list"] = builder(replay["odp_required_list"], replay["evidence_spans"], registry)
    assert_request_only(original, replay)
    return replay


def validate_window(original: dict, row: dict, matched: dict) -> list[str]:
    for field in ("context_sha256", "evidence_window_sha256"):
        if row[field] != matched[field]:
            raise ValueError(f"Parent window identity differs for question {row['query_id']}: {field}")
    window = matched["evidence_window_source_ids"].split("|")
    selected = [span["source_id"] for span in original["evidence_spans"]]
    if selected != window:
        raise ValueError(f"Parent contract does not retain the complete ordered window: {row['query_id']}")
    return window


def load_builder(repo_root: Path, extractor, sentinel: str):
    path = repo_root / "src/compliancegpt/pipeline/pipeline.py"
    text = path.read_text()
    tree = ast.parse(text)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "_build_ask_list"]
    if len(functions) != 1:
        raise ValueError("Pinned production request builder was not found exactly once")
    node = functions[0]
    namespace = {"Any": Any, "Dict": Dict, "List": List,
                 "_extract_odp_ids": extractor, "_ASSIGNMENT_REQUIRED_SENTINEL": sentinel}
    module = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
    exec(compile(module, str(path), "exec"), namespace)
    provenance = {"source_path": "src/compliancegpt/pipeline/pipeline.py", "symbol": "_build_ask_list",
                  "module_sha256": file_digest(path), "function_sha256": digest(ast.get_source_segment(text, node).encode()),
                  "load_method": "Unchanged function AST with production marker extractor and sentinel"}
    return namespace["_build_ask_list"], provenance


def request_metrics(contract: dict) -> dict:
    requests = contract.get("ask_list", [])
    prompt_words = sum(len(str(r.get("ask_prompt", "")).split()) for r in requests)
    return {"request_count": len(requests), "request_prompt_word_count": prompt_words,
            "answer_and_request_prompt_word_count": len(contract["answer_text"].split()) + prompt_words,
            "declared_parameter_count": len(contract.get("odp_required_list", [])),
            "request_payload_char_count": len(json.dumps(requests, ensure_ascii=False, sort_keys=True, separators=(",", ":")))}


def verify_recorded_metrics(metrics: dict, row: dict) -> None:
    fields = ("runtime_contract_pass", "full_gold_clause_coverage", "right_control", "any_gold_clause",
              "gold_clause_precision", "selected_clause_count", "gold_clause_count", "additional_evidence_count",
              "answer_char_count", "answer_word_count", "citation_char_count", "gold_odp_count", "generated_odp_count", "exact_odp_list")
    for field in fields:
        expected = row[field]
        value = metrics[field]
        valid = (value == (expected.lower() == "true")) if isinstance(value, bool) else abs(float(value) - float(expected)) < 1e-12
        if not valid:
            raise ValueError(f"Original metric does not reproduce for {row['query_id']}: {field}")


def summarize(rows: list[dict], ablation, scoring) -> dict:
    # The historical helper calls C 'offline_strict_pass'; provide S explicitly.
    adapted = [{**r, "offline_strict_pass": r["strict_pass"]} for r in rows]
    result = ablation.aggregate(adapted)
    result["strict_pass"] = scoring.rate_record(result.pop("offline_strict_pass")["count"], len(rows))
    result["contract_checks_pass"] = scoring.rate_record(sum(r["contract_checks_pass"] for r in rows), len(rows))
    result["parameter_accounting_failures"] = sum(not r["complete_parameter_accounting"] for r in rows)
    result["exact_provenance_failures"] = sum(not r["exact_provenance"] for r in rows)
    result["review_methods"] = dict(sorted(Counter(r["review_method"] for r in rows).items()))
    covered = [r for r in rows if r["full_gold_clause_coverage"]]
    result["coverage_complete_realization_loss"] = {"n": len(covered), "count": sum(not r["strict_pass"] for r in covered),
                                                    "rate": sum(not r["strict_pass"] for r in covered) / len(covered)}
    for field in ("request_count", "request_prompt_word_count", "answer_and_request_prompt_word_count",
                  "declared_parameter_count", "request_payload_char_count", "generated_odp_count"):
        result["review_burden"][field] = ablation.distribution([r[field] for r in rows])
    negatives = result["non_odp_status_expansion"]
    result["odp_status_specificity"] = {"count": negatives["n"] - negatives["params_required_count"],
                                         "n": negatives["n"],
                                         "rate": (negatives["n"] - negatives["params_required_count"]) / negatives["n"]}
    return result


def named_pairs(left: list[dict], right: list[dict], field: str, scoring) -> dict:
    lhs = {r["query_id"]: {"strict_pass": r[field]} for r in left}
    rhs = {r["query_id"]: {"strict_pass": r[field]} for r in right}
    return scoring.paired_strict_pass(lhs, rhs)


def compare(main: list[dict], replay: list[dict], scoring) -> dict:
    pairs = {field: named_pairs(main, replay, field, scoring) for field in ("strict_pass", "full_gold_clause_coverage")}
    main_negative = [r for r in main if r["gold_odp_count"] == 0]
    replay_negative = [r for r in replay if r["gold_odp_count"] == 0]
    for row in main_negative + replay_negative:
        row["avoids_params_required"] = row["status"] != "PARAMS_REQUIRED"
    pairs["odp_status_specificity"] = named_pairs(main_negative, replay_negative, "avoids_params_required", scoring)
    pairs["orientation"] = {"left": "main selector path", "right": "no-selector with request construction"}
    return pairs


def render_report(summary: dict) -> str:
    text = ["NO-SELECTOR REQUEST-CONSTRUCTION REPLAY", "", f"Result identity: {RESULT_ID}",
            "Endpoint: strict-pass-v1. Retrospective replay of 136 frozen questions.", "",
            "The replay constructs requests on copies of the original no-selector contracts. Every other contract field remains unchanged.",
            "The three conditions use the same labels and matched available windows. Full-window retention and the main selector path retain different evidence.", ""]
    for revision, data in summary["revisions"].items():
        text.extend([revision.upper(), ""])
        for label in ("main_selector", "original_no_selector", "no_selector_requests"):
            row = data["configurations"][label]
            strict = row["strict_pass"]
            coverage = row["full_gold_clause_coverage"]
            spec = row["odp_status_specificity"]
            burden = row["review_burden"]
            text.append(f"{label}: strict {strict['count']}/{strict['n']}; full coverage {coverage['count']}/{row['n_questions']}; "
                        f"specificity {spec['count']}/{spec['n']}; mean answer words {burden['answer_word_count']['mean']:.1f}; "
                        f"mean source precision {burden['gold_clause_precision']['mean']:.3f}; mean requests {burden['request_count']['mean']:.2f}; "
                        f"mean combined words {burden['answer_and_request_prompt_word_count']['mean']:.1f}.")
        pair = data["paired_vs_main"]["strict_pass"]
        text.extend(["", f"Paired strict outcomes: selector only {pair['left_only']}, replay only {pair['right_only']}, "
                     f"both {pair['both_pass']}, neither {pair['neither_pass']}; exact McNemar p = {pair['exact_mcnemar_two_sided_p']:.8g}.",
                     f"Replay failures: {', '.join(data['replay_failure_query_ids'])}.", ""])
    text.extend(["INTERPRETATION", "",
                 "Request construction removes failures caused by the original empty request lists. It does not recover clauses or parameters absent from the retained scope.",
                 "The main selector path returns shorter bodies, retains fewer additional source IDs, and requests parameters on fewer reference-negative questions.",
                 "The request-constructed full-window path passes more frozen questions under this endpoint. Its larger outputs and request scope describe a coverage-versus-burden tradeoff.",
                 "Word counts and identifier precision do not measure analyst effort. Additional IDs are absent from the reference; their absence does not prove irrelevance.",
                 "The original registries remain in use, including known prompt defects. Strict-pass-v1 excludes clarification value-domain correctness and independent professional acceptance.",
                 "These paired comparisons are retrospective, exploratory, and unadjusted. Curated questions and author labels limit population and causal interpretations.", ""])
    return "\n".join(text)


def run(repo_root: Path, baseline_path: Path, output_dir: Path) -> dict:
    repo_root = repo_root.resolve()
    output_dir = output_dir.resolve()
    if output_dir == repo_root or repo_root in output_dir.parents:
        raise ValueError("Write replay results outside the frozen source checkout")
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValueError("The replay output destination must be empty")
    baseline = json.loads(baseline_path.read_text())
    expected = dict(baseline["main_input_sha256"])
    for item in baseline["pinned_artifacts"] + baseline["additional_patch_inputs"]:
        if item["checkout"] == "repo_pin" and item.get("role") != "outputs":
            expected[item["path"]] = item["sha256"]
    # Verify only relevant replay inputs, code, and original ledgers, not other studies.
    relevant = set(baseline["main_input_sha256"]) | {
        "src/compliancegpt/pipeline/pipeline.py", "src/compliancegpt/pipeline/odp_policy.py",
        "src/compliancegpt/generator/verifier/verifier.py", "src/answerer_comparison/strict_pass.py",
        f"{BASE}/run_strict_pass.py", f"{BASE}/strict_pass_reviews.jsonl",
        "data/ODP/rev4/odp_registry_rev4.json", "data/ODP/rev5/odp_registry_rev5.json",
        f"{BASE}/rq2_no_selector/results_v1/contracts/rev4_no_selector.csv",
        f"{BASE}/rq2_no_selector/results_v1/contracts/rev5_no_selector.csv",
    }
    expected = {p: expected[p] for p in sorted(relevant)}
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo_root, text=True).strip()
    if head != SOURCE_COMMIT:
        raise ValueError("Use the dissertation's pinned evaluation checkout for this replay")
    # Bind auxiliary metric helpers to their exact Git objects at the same pin.
    auxiliary_paths = [f"{BASE}/rq2_no_selector/run_no_selector_ablation.py",
                       f"{BASE}/rq2_frontier_baseline/run_frontier_baseline.py",
                       f"{BASE}/rq2_frontier_baseline_rev5/run_frontier_baseline_rev5.py"]
    for relative in auxiliary_paths:
        expected[relative] = digest(subprocess.check_output(["git", "show", f"{SOURCE_COMMIT}:{relative}"], cwd=repo_root))
    hashes_before = verify_sources(repo_root, expected)
    sys.path[:0] = [str(repo_root), str(repo_root / "src")]
    from answerer_comparison import strict_pass as scoring
    from experiments.answerer_comparison.run_strict_pass import load_inputs
    from experiments.answerer_comparison.rq2_no_selector import run_no_selector_ablation as ablation
    from compliancegpt.pipeline.odp_policy import extract_odp_ids, ASSIGNMENT_REQUIRED_SENTINEL
    from compliancegpt.generator.verifier.verifier import verify_answer, verify_contract_validity, normalize_odp_id
    if scoring.RULE_VERSION != "strict-pass-v1":
        raise ValueError("The replay requires the frozen strict-pass-v1 endpoint")
    inputs, loaded_hashes = load_inputs(repo_root)
    if loaded_hashes != baseline["main_input_sha256"]:
        raise ValueError("Main input identities differ from the Batch 1 baseline")
    reviews = scoring.load_reviews(repo_root / f"{BASE}/strict_pass_reviews.jsonl")
    builder, builder_provenance = load_builder(repo_root, extract_odp_ids, ASSIGNMENT_REQUIRED_SENTINEL)
    summary = {"schema_version": "compliancegpt-no-selector-requests-v1", "result_id": RESULT_ID,
               "parent_result_id": PARENT_RESULT_ID, "source_commit": SOURCE_COMMIT, "rule_version": scoring.RULE_VERSION,
               "study_type": "retrospective deterministic replay", "unique_questions": 136,
               "contract_assessments": 408, "new_model_calls": 0, "changed_contract_field": "ask_list",
               "request_builder": builder_provenance, "revisions": {}}
    assessments = []
    replay_contracts = []
    change_rows = []
    comparison_rows = []
    failures = []
    validation_checks = []
    contract_tables = {}
    for revision, (records, gold, systems) in inputs.items():
        registry = json.loads((repo_root / f"data/ODP/{revision}/odp_registry_{revision}.json").read_text())
        parent_rows = read_rows(repo_root / f"{BASE}/rq2_no_selector/results_v1/contracts/{revision}_no_selector.csv")
        if set(parent_rows) != set(gold):
            raise ValueError("No-selector and gold question sets differ")
        corpus = {key: record["text"] for key, record in records.items()}
        by_condition = {name: [] for name in ("main_selector", "original_no_selector", "no_selector_requests")}
        local_contract_rows = []
        for qid in sorted(gold, key=int):
            parent_row = parent_rows[qid]
            main_row = systems["compliancegpt"][qid]
            original = json.loads(parent_row["contract_json"])
            main = json.loads(main_row["contract_json"])
            window = validate_window(original, parent_row, main_row)
            replay = construct_requests(original, registry, builder)
            changes = assert_request_only(original, replay)
            fixed_hash = canonical_digest({k: v for k, v in original.items() if k != "ask_list"})
            if fixed_hash != canonical_digest({k: v for k, v in replay.items() if k != "ask_list"}):
                raise ValueError("Non-request contract content changed")
            row_results = {}
            for name, contract in (("main_selector", main), ("original_no_selector", original), ("no_selector_requests", replay)):
                metrics = ablation.evaluate_contract(contract=contract, gold_row=gold[qid], corpus=corpus,
                    revision=revision, verify_answer=verify_answer, verify_contract_validity=verify_contract_validity,
                    normalize_odp_id=normalize_odp_id)
                contract_pass = metrics.pop("offline_strict_pass")
                result = scoring.evaluate_contract(revision=revision, query_id=qid, contract=contract,
                    gold=gold[qid], records=records, window_ids=window, reviews=reviews)
                if result["contract_checks_pass"] != contract_pass:
                    raise ValueError("Legacy contract check and strict scorer disagree")
                if name == "original_no_selector":
                    verify_recorded_metrics(metrics, parent_row)
                    if contract_pass != (parent_row["offline_strict_pass"].lower() == "true"):
                        raise ValueError("Original no-selector contract check does not reproduce")
                if name == "main_selector" and contract_pass != (main_row["verifier_pass"].lower() == "true"):
                    raise ValueError("Original selector contract check does not reproduce")
                joined = {**metrics, **result, **request_metrics(contract), "condition": name}
                if joined["strict_pass"] and not joined["full_gold_clause_coverage"]:
                    raise ValueError("Strict pass lacks complete clause coverage")
                by_condition[name].append(joined)
                row_results[name] = joined
                assessments.append({**joined, "question": original["question"],
                                    "context_sha256": main_row["context_sha256"],
                                    "evidence_window_sha256": main_row["evidence_window_sha256"]})
            for field in ("offline_error_tags", "offline_metrics", "runtime_contract_pass", "runtime_error_tags",
                          "full_gold_clause_coverage", "any_gold_clause", "right_control", "gold_clause_precision",
                          "selected_clause_count", "gold_clause_count", "additional_evidence_count", "answer_char_count",
                          "answer_word_count", "citation_char_count", "status", "gold_odp_count", "generated_odp_count",
                          "exact_odp_list", "gold_odps", "generated_odps", "contract_checks_pass"):
                if row_results["original_no_selector"][field] != row_results["no_selector_requests"][field]:
                    raise ValueError(f"Request construction changed a fixed metric: {revision}/{qid}/{field}")
            if row_results["original_no_selector"]["strict_pass"] and not row_results["no_selector_requests"]["strict_pass"]:
                raise ValueError("Request construction lost an original strict pass")
            wrapper = {"revision": revision, "query_id": qid, "result_id": RESULT_ID,
                       "parent_result_id": PARENT_RESULT_ID, "original_contract_json_sha256": digest(parent_row["contract_json"].encode()),
                       "original_contract_sha256": canonical_digest(original), "replay_contract_sha256": canonical_digest(replay),
                       "unchanged_non_request_fields_sha256": fixed_hash, "changed_fields": changes,
                       "context_sha256": main_row["context_sha256"], "evidence_window_sha256": main_row["evidence_window_sha256"],
                       "contract": replay}
            replay_contracts.append(wrapper)
            local_contract_rows.append({"query_id": qid, "revision": revision, "result_id": RESULT_ID,
                                        "strict_pass": row_results["no_selector_requests"]["strict_pass"],
                                        "contract_checks_pass": row_results["no_selector_requests"]["contract_checks_pass"],
                                        "context_sha256": main_row["context_sha256"], "evidence_window_sha256": main_row["evidence_window_sha256"],
                                        "evidence_window_source_ids": "|".join(window), "contract_json": replay})
            change_rows.append({key: value for key, value in wrapper.items() if key != "contract"})
            comparison_rows.append({"revision": revision, "query_id": qid, "question": original["question"],
                                    "main_strict_pass": row_results["main_selector"]["strict_pass"],
                                    "original_no_selector_strict_pass": row_results["original_no_selector"]["strict_pass"],
                                    "no_selector_requests_strict_pass": row_results["no_selector_requests"]["strict_pass"],
                                    "newly_passes_after_request_construction": not row_results["original_no_selector"]["strict_pass"] and row_results["no_selector_requests"]["strict_pass"],
                                    "changed_fields": changes,
                                    **{f"{name}_{field}": row_results[name][field] for name in ("main_selector", "no_selector_requests")
                                       for field in ("full_gold_clause_coverage", "answer_word_count", "gold_clause_precision",
                                                     "selected_clause_count", "additional_evidence_count", "status", "request_count",
                                                     "request_prompt_word_count", "answer_and_request_prompt_word_count")}})
            if not row_results["no_selector_requests"]["strict_pass"]:
                failure = row_results["no_selector_requests"]
                failures.append({"revision": revision, "query_id": qid, "question": original["question"],
                                 "full_gold_clause_coverage": failure["full_gold_clause_coverage"],
                                 "contract_errors": failure["contract_errors"], "provenance_errors": failure["provenance_errors"],
                                 "accounting_errors": failure["accounting_errors"], "semantic_findings": failure["semantic_findings"],
                                 "review_method": failure["review_method"]})
        configurations = {name: summarize(rows, ablation, scoring) for name, rows in by_condition.items()}
        paired = compare(by_condition["main_selector"], by_condition["no_selector_requests"], scoring)
        paired_change = named_pairs(by_condition["original_no_selector"], by_condition["no_selector_requests"], "strict_pass", scoring)
        summary["revisions"][revision] = {"configurations": configurations, "paired_vs_main": paired,
                                          "paired_original_vs_requests": paired_change,
                                          "changed_contracts": sum(bool(r["changed_fields"]) for r in change_rows if r["revision"] == revision),
                                          "newly_strict_passing_questions": [r["query_id"] for r in comparison_rows if r["revision"] == revision and r["newly_passes_after_request_construction"]],
                                          "replay_failure_query_ids": [r["query_id"] for r in failures if r["revision"] == revision]}
        contract_tables[revision] = local_contract_rows
        validation_checks.append({"revision": revision, "rows": len(gold), "full_ordered_windows_validated": True,
                                  "all_non_request_contract_fields_unchanged": True, "all_fixed_metrics_unchanged": True,
                                  "recorded_contract_checks_reproduced": True, "recorded_no_selector_metrics_reproduced": True})
    hashes_after = verify_sources(repo_root, expected)
    if hashes_before != hashes_after:
        raise ValueError("Frozen inputs changed during the replay")
    baseline_summary = json.loads((repo_root / f"{BASE}/rq2_no_selector/results_v1/summary.json").read_text())
    for revision, data in summary["revisions"].items():
        for name, baseline_name in (("main_selector", "selector_v3"), ("original_no_selector", "no_selector_v1")):
            current = data["configurations"][name]
            recorded = baseline_summary["revisions"][revision][baseline_name]
            if current["strict_pass"]["count"] != recorded["offline_strict_pass"]["count"]:
                raise ValueError(f"Frozen strict baseline differs: {revision}/{name}")
            for field in ("full_gold_clause_coverage", "right_control", "any_gold_clause", "status_counts", "odp_subset", "non_odp_status_expansion"):
                if current[field] != recorded[field]:
                    raise ValueError(f"Frozen aggregate differs: {revision}/{name}/{field}")
            for field, values in recorded["review_burden"].items():
                if any(abs(current["review_burden"][field][key] - value) > 1e-12 for key, value in values.items()):
                    raise ValueError(f"Frozen burden aggregate differs: {revision}/{name}/{field}")
    validation = {"result_id": RESULT_ID, "all_checks_passed": True, "checks": validation_checks,
                  "source_hashes_unchanged": hashes_before == hashes_after,
                  "original_and_main_aggregate_baselines_reproduced": True,
                  "new_semantic_review_records": 0,
                  "body_assessment_methods": dict(sorted(Counter(r["review_method"] for r in assessments).items()))}
    output_dir.mkdir(parents=True, exist_ok=True)
    for revision, rows in contract_tables.items():
        write_csv(output_dir / f"contracts/{revision}_no_selector_requests.csv", rows)
    write_json(output_dir / "summary.json", summary)
    write_json(output_dir / "validation.json", validation)
    write_jsonl(output_dir / "strict_pass_rows.jsonl", assessments)
    write_csv(output_dir / "strict_pass_rows.csv", assessments)
    write_jsonl(output_dir / "replay_contracts.jsonl", replay_contracts)
    write_jsonl(output_dir / "contract_changes.jsonl", change_rows)
    write_jsonl(output_dir / "remaining_failures.jsonl", failures)
    write_csv(output_dir / "per_question_comparison.csv", comparison_rows)
    (output_dir / "REPORT.txt").write_text(render_report(summary))
    main_table = []
    for revision, data in summary["revisions"].items():
        for condition, row in data["configurations"].items():
            main_table.append({"revision": revision, "condition": condition, "strict_pass_count": row["strict_pass"]["count"],
                               "n": row["n_questions"], "full_clause_coverage": row["full_gold_clause_coverage"]["count"],
                               "mean_answer_words": row["review_burden"]["answer_word_count"]["mean"],
                               "mean_source_precision": row["review_burden"]["gold_clause_precision"]["mean"],
                               "specificity_count": row["odp_status_specificity"]["count"], "specificity_n": row["odp_status_specificity"]["n"],
                               "mean_requests": row["review_burden"]["request_count"]["mean"],
                               "mean_request_prompt_words": row["review_burden"]["request_prompt_word_count"]["mean"],
                               "mean_combined_words": row["review_burden"]["answer_and_request_prompt_word_count"]["mean"]})
    write_csv(output_dir / "comparison_table.csv", main_table)
    manifest = {"result_id": RESULT_ID, "parent_result_id": PARENT_RESULT_ID, "source_commit": SOURCE_COMMIT,
                "rule_version": scoring.RULE_VERSION, "baseline_manifest_sha256": file_digest(baseline_path),
                "protocol_sha256": file_digest(HERE / "PROTOCOL.txt"), "replay_script_sha256": file_digest(Path(__file__)),
                "input_sha256": hashes_before, "input_hashes_unchanged_after_execution": True,
                "request_builder": builder_provenance,
                "output_sha256": {p.relative_to(output_dir).as_posix(): file_digest(p) for p in sorted(output_dir.rglob("*")) if p.is_file()},
                "generation": "No retrieval, model inference, fallback, rescue, hierarchy expansion, or gold-guided request construction",
                "limitations": "Retrospective replay; frozen author labels; strict-pass-v1 excludes clarification meaning; burden proxies only"}
    write_json(output_dir / "manifest.json", manifest)
    print(json.dumps({"result_id": RESULT_ID, "all_checks_passed": True,
                      "strict_pass": {rev: {name: cfg["strict_pass"]["count"] for name, cfg in data["configurations"].items()}
                                      for rev, data in summary["revisions"].items()},
                      "changed_contracts": len([r for r in change_rows if r["changed_fields"]]),
                      "newly_passing": len([r for r in comparison_rows if r["newly_passes_after_request_construction"]])}))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--baseline-manifest", type=Path, default=HERE / "inputs/baseline_manifest.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    run(args.repo_root, args.baseline_manifest, args.output_dir)


if __name__ == "__main__":
    main()
