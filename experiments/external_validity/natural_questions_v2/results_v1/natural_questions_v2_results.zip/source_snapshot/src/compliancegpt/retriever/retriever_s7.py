"""

RETRIEVER_PATCH_ID = "2026-02-21-leafbudget8-clause-rerank"

retriever_s7.py - S7 retriever component for ComplianceGPT

Design goals (clean + pipeline-friendly)
- Single, unambiguous path name: `ccs_path` (NO catalog_path/ccs_path duality).
- Single retriever class: `ComplianceGPTRetriever`.
- Single config class: `RetrievalConfig`.
- Output docs are clause-level dicts the Generator can consume directly:
    { "id", "control_id", "kind", "title", "text" }

Retrieval idea
- Control ranking: weighted RRF fusion over BM25(control) + Dense(control via clause adapter)
- Optional rerank: cross-encoder scoring + blended ranking + adoption gate
- Evidence selection: return multiple clause snippets per top control (statement + guidance, etc.)

Dependencies (same as before)
- numpy
- sentence-transformers
- faiss-cpu (or faiss-gpu)
- torch
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Tuple, Set

import numpy as np


# ==========================================================
# 1) Text utils / normalization
# ==========================================================
_PUNCT_RE = re.compile(r"[^0-9A-Za-z_\s]+")
_WS_RE = re.compile(r"\s+")
_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")

# Control ID normalization helpers
_CONTROL_ID_DOT_RE = re.compile(r"^([A-Z]{2,3}-\d+)\.(\d+)$")
_CONTROL_ID_PAREN_RE = re.compile(r"^([A-Z]{2,3}-\d+)\((\d+)\)$")


def normalize_text(text: str) -> str:
    if not isinstance(text, str):
        text = "" if text is None else str(text)
    s = text.lower().replace("-", " ")
    s = _PUNCT_RE.sub(" ", s)
    return _WS_RE.sub(" ", s).strip()


def tokenize(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN_RE.findall(str(text))]


def normalize_control_id(control_id: str) -> str:
    """Normalize control IDs to a canonical form.

    Canonicalization rules:
      - Upper-case, '_' -> '-'
      - Enhancement dot form (e.g., 'AC-2.1') is converted to parentheses form ('AC-2(1)')
    """
    if not isinstance(control_id, str):
        return ""
    cid = control_id.strip().upper().replace("_", "-")

    m_dot = _CONTROL_ID_DOT_RE.match(cid)
    if m_dot:
        return f"{m_dot.group(1)}({m_dot.group(2)})"

    if _CONTROL_ID_PAREN_RE.match(cid):
        return cid

    return cid


def control_id_aliases(control_id: str) -> str:
    """Return a space-separated set of ID aliases for indexing/matching.

    Includes:
      - canonical form
      - hyphenless and spaced variants
      - dot/parentheses enhancement variants (both directions)
    """
    cid = normalize_control_id(control_id)
    aliases: set[str] = set()

    def _add(x: str) -> None:
        if not x:
            return
        aliases.add(x)
        aliases.add(x.replace("-", ""))
        aliases.add(x.replace("-", " "))

    _add(cid)

    m_paren = _CONTROL_ID_PAREN_RE.match(cid)
    if m_paren:
        dot = f"{m_paren.group(1)}.{m_paren.group(2)}"
        _add(dot)
    else:
        m_dot = _CONTROL_ID_DOT_RE.match(cid)
        if m_dot:
            paren = f"{m_dot.group(1)}({m_dot.group(2)})"
            _add(paren)

    return " ".join(sorted(aliases))


def jaccard_overlap(a: str, b: str) -> float:
    A = set(tokenize(normalize_text(a)))
    B = set(tokenize(normalize_text(b)))
    if not A or not B:
        return 0.0
    return len(A & B) / float(len(A | B))


def normalize_scores_minmax(x: np.ndarray) -> np.ndarray:
    """Map scores to [0,1] robustly (flat -> zeros)."""
    if x.size == 0:
        return x
    mn, mx = float(np.min(x)), float(np.max(x))
    if mx - mn < 1e-12:
        return np.zeros_like(x, dtype=np.float32)
    return ((x - mn) / (mx - mn)).astype(np.float32)


# ==========================================================
# 1b) Retrieval-query planning (generic, category-level)
# ==========================================================
_RETRIEVAL_META_PATTERNS = (
    re.compile(r"\b(?:under|based on|in)\s+nist\s+sp\s*800\s*[-–]?\s*53\b", re.IGNORECASE),
    re.compile(r"\bplease\s+(?:also\s+)?include\s+(?:the\s+)?control\s+citation(?:s)?\b", re.IGNORECASE),
    re.compile(r"\binclude\s+(?:the\s+)?control\s+citation(?:s)?\b", re.IGNORECASE),
    re.compile(r"\binclude\s+(?:the\s+)?citation(?:s)?\b", re.IGNORECASE),
    re.compile(r"\bwith\s+(?:the\s+)?control\s+citation(?:s)?\b", re.IGNORECASE),
    re.compile(r"\bwith\s+(?:the\s+)?citation(?:s)?\b", re.IGNORECASE),
    re.compile(r"\b(?:what|which)\s+control\s+(?:says|requires|covers)\b", re.IGNORECASE),
    re.compile(r"\bcontrol\s+citation(?:s)?\b", re.IGNORECASE),
)

_ADMIN_PAT = re.compile(r"\badmins?\b|\badministrators?\b|\bsuperusers?\b|\broot\b", re.IGNORECASE)
_NON_PRIV_PAT = re.compile(r"\bnon[\s-]?privileged\b|\bregular\s+users?\b|\bordinary\s+users?\b", re.IGNORECASE)
_PRIV_PAT = re.compile(r"\bprivileged\b", re.IGNORECASE)
_MFA_PAT = re.compile(r"\bmfa\b|\bmulti[\s-]?factor\b|\bmultifactor\b", re.IGNORECASE)


def _mentions_mfa(text: str) -> bool:
    return bool(_MFA_PAT.search(str(text or "")))


def _detect_privilege_scope(text: str) -> str:
    q = str(text or "")
    if _NON_PRIV_PAT.search(q):
        return "non_privileged"
    if _PRIV_PAT.search(q) or _ADMIN_PAT.search(q):
        return "privileged"
    return "neutral"


def _control_privilege_scope(text: str) -> str:
    q = str(text or "")
    if _NON_PRIV_PAT.search(q):
        return "non_privileged"
    if _PRIV_PAT.search(q):
        return "privileged"
    return "neutral"


def _strip_retrieval_meta(text: str) -> Tuple[str, List[str]]:
    raw = str(text or "").strip()
    if not raw:
        return "", []
    out = raw
    notes: List[str] = []
    for pat in _RETRIEVAL_META_PATTERNS:
        new_out = pat.sub(" ", out)
        if new_out != out:
            notes.append(pat.pattern)
            out = new_out
    out = re.sub(r"\b(?:please|kindly)\b", " ", out, flags=re.IGNORECASE)
    out = re.sub(r"[,:;]+", " ", out)
    out = _WS_RE.sub(" ", out).strip(" .,-:\n\t")
    return out, notes


def build_retrieval_query(
    query: str,
    *,
    strip_meta: bool = True,
    expand_scope_terms: bool = True,
) -> Tuple[str, Dict[str, Any]]:
    raw = str(query or "").strip()
    if not raw:
        return "", {"raw_query": "", "retrieval_query": "", "scope": "neutral", "meta_removed": [], "expansions": []}

    scope = _detect_privilege_scope(raw)
    work = raw
    removed: List[str] = []
    if strip_meta:
        work, removed = _strip_retrieval_meta(work)
        if not work:
            work = raw

    expansions: List[str] = []
    q_norm = normalize_text(work)
    if expand_scope_terms:
        if _mentions_mfa(q_norm):
            expansions.extend(["multi-factor authentication", "mfa"])
        if scope == "privileged":
            expansions.extend(["privileged account", "privileged accounts"])
            if _ADMIN_PAT.search(raw):
                expansions.extend(["privileged user", "privileged users"])
        elif scope == "non_privileged":
            expansions.extend(["non-privileged account", "non-privileged accounts", "non-privileged user"])

    extras: List[str] = []
    seen_extra: Set[str] = set()
    low_work = work.lower()
    for e in expansions:
        ee = str(e or "").strip()
        if not ee:
            continue
        eel = ee.lower()
        if eel in low_work or eel in seen_extra:
            continue
        seen_extra.add(eel)
        extras.append(ee)

    retrieval_query = work
    if extras:
        retrieval_query = (work + " " + " ".join(extras)).strip()

    retrieval_query = _WS_RE.sub(" ", retrieval_query).strip()
    if not retrieval_query:
        retrieval_query = raw

    meta = {
        "raw_query": raw,
        "retrieval_query": retrieval_query,
        "scope": scope,
        "meta_removed": removed,
        "expansions": extras,
        "changed": retrieval_query != raw,
    }
    return retrieval_query, meta


def _apply_privilege_scope_bias(
    rrf_scores: Dict[str, float],
    *,
    query_scope: str,
    control_text_by_control: Dict[str, str],
    match_ratio: float,
    mismatch_ratio: float,
) -> Dict[str, float]:
    if query_scope not in {"privileged", "non_privileged"}:
        return {"query_scope": query_scope, "applied": False, "reason": "neutral_query_scope"}
    if not rrf_scores:
        return {"query_scope": query_scope, "applied": False, "reason": "no_candidates"}

    try:
        peak = max(float(v) for v in rrf_scores.values())
    except Exception:
        peak = 0.0
    if peak <= 0.0:
        return {"query_scope": query_scope, "applied": False, "reason": "nonpositive_scores"}

    bonus = max(0.0, float(match_ratio)) * peak
    penalty = max(0.0, float(mismatch_ratio)) * peak
    matched = 0
    penalized = 0

    for cid in list(rrf_scores.keys()):
        surface_scope = _control_privilege_scope(control_text_by_control.get(cid, ""))
        if surface_scope == "neutral":
            continue
        if surface_scope == query_scope:
            rrf_scores[cid] = float(rrf_scores.get(cid, 0.0)) + bonus
            matched += 1
        else:
            rrf_scores[cid] = float(rrf_scores.get(cid, 0.0)) - penalty
            penalized += 1

    return {
        "query_scope": query_scope,
        "applied": bool(matched or penalized),
        "match_bonus": float(bonus),
        "mismatch_penalty": float(penalty),
        "matched_controls": int(matched),
        "penalized_controls": int(penalized),
    }


# ==========================================================
# 2) CCS JSONL loader (clause-level)
# ==========================================================
def load_clause_records_jsonl(
    ccs_path: str,
    keep_kinds: Iterable[str] = ("smt", "gdn"),
) -> List[Dict[str, Any]]:
    """
    Expected CCS line schema (minimum):
        {
          "id": "...",           # clause id (unique)
          "control_id": "AC-1",  # normalized to AC-1
          "text": "...",         # clause text
          "kind": "smt|gdn|..."  # optional; filtered by keep_kinds
          "title": "..."         # optional
        }
    """
    keep = set(k.lower() for k in keep_kinds) if keep_kinds else set()
    out: List[Dict[str, Any]] = []

    with open(ccs_path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            rec = json.loads(line)

            kind = str(rec.get("kind", "other")).lower()
            if keep and kind not in keep:
                continue

            txt = str(rec.get("text", "")).strip()
            if not txt:
                continue

            clause_id = str(rec.get("id", "")).strip()
            if not clause_id:
                continue

            out.append(
                {
                    "id": clause_id,
                    "control_id": normalize_control_id(rec.get("control_id") or rec.get("control") or ""),
                    "title": str(rec.get("title", "")).strip(),
                    "text": txt,
                    "kind": kind,
                }
            )
    return out


def load_all_records_by_id_jsonl(ccs_path: str) -> Dict[str, Dict[str, Any]]:
    """
    Load ALL CCS records into an id->record map (including params like odp/prm).

    Important: retrieval corpora should still be built from clause-only kinds
    (e.g., smt/gdn) via load_clause_records_jsonl(). This function is for
    inventory/verification/canonicalization purposes only.
    """
    out: Dict[str, Dict[str, Any]] = {}
    with open(ccs_path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            rec = json.loads(line)
            if not isinstance(rec, dict):
                continue

            rid = str(rec.get("id", "")).strip()
            if not rid:
                continue

            kind = str(rec.get("kind", "other")).lower().strip()
            txt = str(rec.get("text", "")).strip()

            # Normalize control id when present (some records may not have one)
            ctl_raw = rec.get("control_id") or rec.get("control") or ""
            ctl = normalize_control_id(ctl_raw)

            # Keep original fields but ensure canonical keys exist
            merged = dict(rec)
            merged["id"] = rid
            merged["kind"] = kind
            merged["text"] = txt
            merged["title"] = str(rec.get("title", "")).strip()
            merged["control_id"] = ctl

            out[rid] = merged

    return out


def build_control_docs_from_clauses(records: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """
    Control-level pseudo-docs for BM25:
    - prepend control id aliases + title
    - append all clause texts for that control
    """
    by_ctl: Dict[str, List[str]] = defaultdict(list)
    titles: Dict[str, str] = {}
    for r in records:
        cid = r.get("control_id", "")
        if not cid:
            continue
        by_ctl[cid].append(r.get("text", ""))
        if r.get("title"):
            titles[cid] = r["title"]

    docs: List[Dict[str, str]] = []
    for cid, parts in by_ctl.items():
        header = [control_id_aliases(cid)]
        if titles.get(cid):
            header.append(titles[cid])
        docs.append({"control_id": cid, "text": "\n".join(header + parts)})
    return docs


def build_control_fallback_text_map(records: List[Dict[str, Any]], max_parts: int = 8) -> Dict[str, str]:
    """
    Build a deterministic per-control text map used for reranker fallback scoring.

    Deterministic priority order before applying max_parts:
      1) Control title
      2) Base statement (e.g., ra-5_smt, ac-2(1)_smt)
      3) Sub-statements (e.g., ra-5_smt.a, ra-5_smt.c.1)
      4) Guidance (e.g., ra-5_gdn, ra-5_gdn.a)

    Notes:
      - This function MUST NOT change its input/output signature.
      - It intentionally excludes non-clause kinds (e.g., odp/prm/obj).
    """
    by_ctl: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in records:
        cid = r.get("control_id", "")
        if cid:
            by_ctl[str(cid)].append(r)

    def _tier(rid: str, kind: str) -> int:
        rid_l = (rid or "").strip().lower()
        k = (kind or "").strip().lower()
        # Prefer explicit kind; fall back to id suffix when kind is missing.
        if k == "smt" or "_smt" in rid_l:
            # Base statement: ends with '_smt' (no '.a', '.1', etc.).
            return 0 if re.search(r"_smt$", rid_l) else 1
        if k == "gdn" or "_gdn" in rid_l:
            return 2
        return 99

    out: Dict[str, str] = {}
    max_n = max(0, int(max_parts))
    for cid, recs in by_ctl.items():
        # Control title (use first non-empty title across records).
        title = ""
        for r in recs:
            t = str(r.get("title", "") or "").strip()
            if t:
                title = t
                break

        scored: List[Tuple[int, str, str]] = []
        for r in recs:
            rid = str(r.get("id", "") or "").strip()
            if not rid:
                continue
            kind = str(r.get("kind", "") or "").strip()
            tier = _tier(rid, kind)
            if tier >= 99:
                continue
            txt = str(r.get("text", "") or "").strip()
            if not txt:
                continue
            scored.append((tier, rid.lower(), txt))

        scored.sort(key=lambda x: (x[0], x[1]))

        parts: List[str] = []
        if title:
            parts.append(f"Control Title: {title}")

        # Take up to max_parts clause texts (after title).
        for tier, _rid, txt in scored[:max_n]:
            parts.append(txt)

        out[normalize_control_id(cid).upper()] = "\n".join(parts).strip()

    return out
class BM25Okapi:
    """Independent Okapi BM25 implementation used by the frozen retriever.

    The default ``k1=1.5`` and ``b=0.75`` match the defaults exposed by the
    commonly used ``rank_bm25`` package. This class is not copied from that
    package: in particular, its IDF expression uses a Lucene-style ``+1``
    form rather than ``rank_bm25``'s negative-IDF epsilon floor. See
    ``CONSTANTS_PROVENANCE.md`` before interpreting or changing the values.
    """

    def __init__(self, corpus_tokens: List[List[str]], k1: float = 1.5, b: float = 0.75):
        self.k1 = float(k1)
        self.b = float(b)
        self.N = len(corpus_tokens)
        self.doc_len = np.array([len(d) for d in corpus_tokens], dtype=np.float32)
        self.avgdl = float(self.doc_len.mean()) if self.N else 0.0

        self.tf: List[Dict[str, int]] = []
        df: Dict[str, int] = {}
        for doc in corpus_tokens:
            tf_doc: Dict[str, int] = {}
            for t in doc:
                tf_doc[t] = tf_doc.get(t, 0) + 1
            self.tf.append(tf_doc)
            for t in tf_doc:
                df[t] = df.get(t, 0) + 1

        self.idf = {t: math.log((self.N - freq + 0.5) / (freq + 0.5) + 1) for t, freq in df.items()}

    def get_scores(self, query_tokens: List[str]) -> np.ndarray:
        scores = np.zeros(self.N, dtype=np.float32)
        for t in query_tokens:
            if t not in self.idf:
                continue
            idf = self.idf[t]
            for i, tf_doc in enumerate(self.tf):
                f = tf_doc.get(t, 0)
                if not f:
                    continue
                num = f * (self.k1 + 1.0)
                den = f + self.k1 * (1.0 - self.b + self.b * (self.doc_len[i] / max(self.avgdl, 1e-9)))
                scores[i] += float(idf) * float(num / den)
        return scores

    def get_top_n(self, query_tokens: List[str], n: int = 10) -> List[int]:
        scores = self.get_scores(query_tokens)
        if n >= len(scores):
            return np.argsort(-scores).tolist()
        idx = np.argpartition(-scores, n - 1)[:n]
        return idx[np.argsort(-scores[idx])].tolist()


def build_bm25(docs: List[Dict[str, str]], k1: float, b: float) -> Tuple[BM25Okapi, List[str]]:
    ids = [d["control_id"] for d in docs]
    toks = [tokenize(normalize_text(d["text"])) for d in docs]
    return BM25Okapi(toks, k1=k1, b=b), ids


# ==========================================================
# 4) Dense index + clause->control adapter
# ==========================================================
class DenseIndex:
    """Clause-level dense retrieval (cosine/IP with normalized embeddings).

    This implementation prefers faiss when available, but can fall back to a
    brute-force numpy inner-product search if faiss is not installed.
    """

    def __init__(self, model_id: str):
        try:
            import torch  # noqa: F401
            from sentence_transformers import SentenceTransformer  # noqa: F401
        except Exception as e:
            raise ImportError(
                "DenseIndex requires sentence-transformers and torch."
            ) from e

        import torch
        from sentence_transformers import SentenceTransformer

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model_id = model_id
        self.model = SentenceTransformer(model_id, device=self.device)

        # faiss is optional
        self._faiss = None
        try:
            import faiss  # type: ignore
            self._faiss = faiss
        except Exception:
            self._faiss = None

        self.index = None
        self.embeddings: Optional[np.ndarray] = None
        self.ids: List[str] = []

    def build(self, texts: List[str], ids: List[str]) -> None:
        self.ids = list(ids)
        emb = self.model.encode(
            texts,
            batch_size=64,
            show_progress_bar=True,
            normalize_embeddings=True,
        )
        emb_np = np.asarray(emb, dtype=np.float32)

        if self._faiss is not None:
            self.index = self._faiss.IndexFlatIP(int(emb_np.shape[1]))
            self.index.add(emb_np)
            self.embeddings = None
            return

        # Numpy fallback (slower, but dependency-light)
        self.index = None
        self.embeddings = emb_np

    def search(self, query: str, top_k: int) -> List[Tuple[str, float]]:
        if top_k <= 0:
            return []

        # Reproduction compatibility: the frozen runs encoded raw transformed
        # queries here even though E5 recommends a ``query: `` prefix. Corpus
        # text is prefixed with ``passage: `` in build_dense_retriever(). Do
        # not silently change this path while claiming comparability with the
        # published metrics; rerun and version any corrected-prefix results.
        q_emb = self.model.encode([query], normalize_embeddings=True)
        q = np.asarray(q_emb, dtype=np.float32)[0]

        if self.index is not None and self._faiss is not None:
            scores, idxs = self.index.search(q.reshape(1, -1), int(top_k))
            out: List[Tuple[str, float]] = []
            for i, s in zip(idxs[0], scores[0]):
                if int(i) == -1:
                    continue
                out.append((self.ids[int(i)], float(s)))
            return out

        if self.embeddings is None or self.embeddings.size == 0:
            return []

        scores_vec = self.embeddings @ q
        n = int(min(int(top_k), int(scores_vec.shape[0])))
        if n <= 0:
            return []

        if n >= int(scores_vec.shape[0]):
            idxs = np.argsort(-scores_vec)
        else:
            part = np.argpartition(-scores_vec, n - 1)[:n]
            idxs = part[np.argsort(-scores_vec[part])]

        out = [(self.ids[int(i)], float(scores_vec[int(i)])) for i in idxs[:n]]
        return out


class ClauseDenseControlAdapter:

    """Clause search -> compress to control by max clause score."""

    def __init__(self, dense_idx: DenseIndex, clause_to_control: Dict[str, str]):
        self.idx = dense_idx
        self.cmap = clause_to_control

    def search(self, query: str, top_k: int = 50) -> List[Tuple[str, float]]:
        # search more clauses than needed, then compress per-control
        hits = self.idx.search(query, top_k=max(10, top_k) * 5)
        best_score: Dict[str, float] = {}
        for clause_id, score in hits:
            ctl = self.cmap.get(clause_id)
            if not ctl:
                continue
            ctl = normalize_control_id(ctl).upper()
            if score > best_score.get(ctl, -1.0):
                best_score[ctl] = float(score)
        ranked = sorted(best_score.items(), key=lambda x: x[1], reverse=True)
        return ranked[:top_k]


def build_dense_retriever(
    records: List[Dict[str, Any]],
    dense_model_id: str,
) -> Tuple[ClauseDenseControlAdapter, Dict[str, str], Dict[str, str], DenseIndex]:
    clause_ids: List[str] = []
    texts: List[str] = []
    clause_to_control: Dict[str, str] = {}
    clause_id_to_packed_text: Dict[str, str] = {}

    for r in records:
        cid = r["control_id"]
        title = r.get("title", "")
        kind = r.get("kind", "other")
        header = f"{control_id_aliases(cid)} {title} ({kind})".strip()
        packed = f"{header}\n{r['text']}".strip()

        clause_id = r["id"]
        clause_ids.append(clause_id)
        texts.append(f"passage: {packed}")  # e5 expects "passage: ..."
        clause_to_control[clause_id] = cid
        clause_id_to_packed_text[clause_id] = packed

    idx = DenseIndex(dense_model_id)
    idx.build(texts, clause_ids)
    return ClauseDenseControlAdapter(idx, clause_to_control), clause_id_to_packed_text, clause_to_control, idx


def build_reranker(model_id: str):
    try:
        import torch  # noqa: F401
        from sentence_transformers import CrossEncoder  # noqa: F401
    except Exception as e:
        raise ImportError("Reranker requires sentence-transformers.") from e

    import torch
    from sentence_transformers import CrossEncoder

    device = "cuda" if torch.cuda.is_available() else "cpu"
    return CrossEncoder(model_id, device=device)


# ==========================================================
# 5) Rewrite handling (pipeline-only, no QUR df here)
# ==========================================================
def _coerce_rewrite_list(rewrites: Any) -> List[str]:
    """
    Accept:
      - list[str]
      - list[dict] with keys rewrite/text
      - single str
    """
    if not rewrites:
        return []
    out: List[str] = []
    if isinstance(rewrites, (list, tuple)):
        for r in rewrites:
            if isinstance(r, str):
                out.append(r)
            elif isinstance(r, dict):
                out.append(r.get("rewrite") or r.get("text") or "")
            else:
                out.append(str(r))
    else:
        out.append(str(rewrites))
    return [x.strip() for x in out if isinstance(x, str) and x.strip()]


def build_query_variants(
    query: str,
    rewrites: Optional[List[str]] = None,
    max_rewrites: Optional[int] = None,
    jaccard_min: Optional[float] = None,
    **_kwargs: Any,
) -> List[str]:
    q = str(query or "").strip()
    if not q:
        return []
    base: List[str] = [q]

    # Keep rewrites in original order, optionally filtered by token Jaccard similarity.
    # This prevents obvious semantic drift from dominating retrieval while staying
    # fully model-agnostic (no gold-driven rules).
    q_toks = set(tokenize(q))
    kept: List[str] = []
    for r in (rewrites or []):
        rr = str(r or "").strip()
        if not rr or rr == q:
            continue
        if jaccard_min is not None and q_toks:
            rr_toks = set(tokenize(rr))
            if rr_toks:
                inter = len(q_toks.intersection(rr_toks))
                union = len(q_toks.union(rr_toks))
                jac = (inter / union) if union else 0.0
                if jac < float(jaccard_min):
                    continue
        kept.append(rr)

    if max_rewrites is not None:
        try:
            m = int(max_rewrites)
            if m >= 0:
                kept = kept[:m]
        except Exception:
            pass

    base.extend(kept)

    def _augment_enhancements(v: str) -> str:
        # Add CCS-friendly dot forms for enhancement controls: AT-2(1) -> AT-2.1
        extras: List[str] = []
        for m in re.finditer(r"\b([A-Za-z]{2}-\d{1,2})\((\d+)\)\b", v or ""):
            b = str(m.group(1) or "").upper()
            n0 = str(m.group(2) or "").strip()
            try:
                n = str(int(n0))
            except Exception:
                n = n0
            if b and n:
                extras.append(f"{b}.{n}")
        if not extras:
            return v
        return str(v) + " " + " ".join(extras + [e.lower() for e in extras])

    out: List[str] = []
    for v in base:
        out.append(v)
        augmented = _augment_enhancements(v)
        if augmented != v:
            out.append(augmented)

    # De-dup preserve order
    seen: Set[str] = set()
    final: List[str] = []
    for v in out:
        if v not in seen:
            seen.add(v)
            final.append(v)
    return final
def s7_rank_controls(
    original_query: str,
    variants: List[str],
    bm25_retriever: BM25Okapi,
    bm25_control_ids: List[str],
    dense_adapter: ClauseDenseControlAdapter,
    reranker,
    reranker_text_by_control: Dict[str, str],
    candidate_set_size: int,
    rrf_k: int,
    rewrite_weight: float,
    rerank_alpha: float,
    rerank_apply_min_margin_ratio: float,
    rerank_skip_enabled: bool = True,
    rerank_skip_min_base_margin_ratio: float = 0.10,
    rerank_skip_require_top1_agreement: bool = False,
    query_scope: str = "neutral",
    scope_match_bias_ratio: float = 0.08,
    scope_mismatch_penalty_ratio: float = 0.06,
) -> Tuple[List[str], Dict[str, Any]]:
    """
    Returns:
      (ranked_control_ids, meta)

    Meta includes:
      - reranker_called: whether cross-encoder was executed (performance proof)
      - rerank_applied: whether the reranked order passed the adoption gate
      - skip_reason: why reranking was skipped (if skipped)
      - base_margin_ratio: confidence of base fused top-1 vs top-2 (raw RRF)
      - rerank_margin_ratio: confidence of reranked top-1 vs top-2 (blended score space)
    """
    weights = [1.0] + [float(rewrite_weight)] * (len(variants) - 1)
    rrf_scores: Dict[str, float] = defaultdict(float)

    # 1) Weighted RRF fusion of BM25 + Dense (both at control granularity)
    for q, w in zip(variants, weights):
        # BM25 (control-level)
        q_toks = tokenize(normalize_text(q))
        idxs = bm25_retriever.get_top_n(q_toks, n=int(candidate_set_size))
        for rank, i in enumerate(idxs, 1):
            cid = normalize_control_id(bm25_control_ids[int(i)]).upper()
            rrf_scores[cid] += float(w) * (1.0 / (float(rrf_k) + float(rank)))

        # Dense (control-level via clause adapter)
        hits = dense_adapter.search(q, top_k=int(candidate_set_size))
        for rank, (raw_cid, _) in enumerate(hits, 1):
            cid = normalize_control_id(str(raw_cid)).upper()
            rrf_scores[cid] += float(w) * (1.0 / (float(rrf_k) + float(rank)))

    scope_bias_meta = _apply_privilege_scope_bias(
        rrf_scores,
        query_scope=str(query_scope or "neutral"),
        control_text_by_control=reranker_text_by_control,
        match_ratio=float(scope_match_bias_ratio),
        mismatch_ratio=float(scope_mismatch_penalty_ratio),
    )

    fused = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)[: int(candidate_set_size)]
    cids_all = [c for c, _ in fused]

    if not cids_all:
        return [], {
            "note": "no_candidates",
            "reranker_called": False,
            "rerank_applied": False,
            "skip_reason": "no_candidates",
            "num_variants": len(variants),
            "scope_bias": scope_bias_meta,
        }

    # Base confidence signal (raw RRF margin ratio).
    base_top1 = cids_all[0]
    base_top2 = cids_all[1] if len(cids_all) >= 2 else ""
    if len(cids_all) >= 2:
        s1 = float(rrf_scores.get(base_top1, 0.0))
        s2 = float(rrf_scores.get(base_top2, 0.0))
        base_margin_ratio = (s1 - s2) / max(s1, 1e-9)
    else:
        base_margin_ratio = 1.0


    # Effective apply threshold for the rerank adoption gate.
    # In uncertain base-ranking scenarios, allow a slightly lower margin requirement so the reranker
    # can correct control-id mistakes without being overly constrained.
    effective_apply_min = float(rerank_apply_min_margin_ratio)
    try:
        if float(base_margin_ratio) < float(rerank_skip_min_base_margin_ratio):
            effective_apply_min = min(effective_apply_min, 0.10)
    except Exception:
        effective_apply_min = float(rerank_apply_min_margin_ratio)

    # Optional agreement signal using original query only (cheap but conservative).
    top1_agree = False
    bm25_top1 = ""
    dense_top1 = ""
    if bool(rerank_skip_require_top1_agreement):
        try:
            q_toks = tokenize(normalize_text(original_query))
            idxs = bm25_retriever.get_top_n(q_toks, n=1)
            if idxs:
                bm25_top1 = normalize_control_id(bm25_control_ids[int(idxs[0])]).upper()
        except Exception:
            bm25_top1 = ""
        try:
            hits = dense_adapter.search(original_query, top_k=1)
            if hits:
                dense_top1 = normalize_control_id(str(hits[0][0])).upper()
        except Exception:
            dense_top1 = ""
        if bm25_top1 and dense_top1 and (base_top1 == bm25_top1 == dense_top1):
            top1_agree = True

    # 2) Pre-rerank skip gate (performance + accuracy)
    if bool(rerank_skip_enabled):
        if base_margin_ratio >= float(rerank_skip_min_base_margin_ratio):
            if (not bool(rerank_skip_require_top1_agreement)) or top1_agree:
                meta = {
                    "num_variants": len(variants),
                    "reranker_called": False,
                    "rerank_applied": False,
                    "skip_reason": "base_confident",
                    "base_top1": base_top1,
                    "base_top2": base_top2,
                    "base_margin_ratio": float(base_margin_ratio),
                    "top1_agree": bool(top1_agree) if bool(rerank_skip_require_top1_agreement) else None,
                    "bm25_top1": bm25_top1 if bool(rerank_skip_require_top1_agreement) else None,
                    "dense_top1": dense_top1 if bool(rerank_skip_require_top1_agreement) else None,
                    "rerank_alpha": float(rerank_alpha),
                    "rerank_apply_min_margin_ratio": float(rerank_apply_min_margin_ratio),
        "rerank_effective_apply_min_margin_ratio": float(effective_apply_min),
                    "rerank_skip_min_base_margin_ratio": float(rerank_skip_min_base_margin_ratio),
                    "rerank_skip_require_top1_agreement": bool(rerank_skip_require_top1_agreement),
                    "final_top1": base_top1,
                    "final_margin_ratio": float(base_margin_ratio),
                    "rerank_margin_ratio": None,
                    "rerank_top1": None,
                    "top_candidates": [],
                    "scope_bias": scope_bias_meta,
                }
                return cids_all, meta

    # 3) Rerank (score blend + adoption gate)
    pairs: List[List[str]] = []
    valid_cids: List[str] = []
    missing_text_cids: List[str] = []
    for cid in cids_all:
        txt = reranker_text_by_control.get(cid, "")
        if txt:
            pairs.append([original_query, txt])
            valid_cids.append(cid)
        else:
            missing_text_cids.append(cid)

    missing_text_set = set(missing_text_cids)

    if not pairs:
        return cids_all, {
            "note": "no_text_for_rerank",
            "reranker_called": False,
            "rerank_applied": False,
            "skip_reason": "no_text_for_rerank",
            "num_variants": len(variants),
            "base_top1": base_top1,
            "base_top2": base_top2,
            "base_margin_ratio": float(base_margin_ratio),
            "rerank_alpha": float(rerank_alpha),
            "rerank_apply_min_margin_ratio": float(rerank_apply_min_margin_ratio),
        "rerank_effective_apply_min_margin_ratio": float(effective_apply_min),
            "rerank_skip_min_base_margin_ratio": float(rerank_skip_min_base_margin_ratio),
            "rerank_skip_require_top1_agreement": bool(rerank_skip_require_top1_agreement),
            "final_top1": base_top1,
            "final_margin_ratio": float(base_margin_ratio),
            "scope_bias": scope_bias_meta,
        }

    pred = reranker.predict(pairs, show_progress_bar=False)

    base_raw = np.array([rrf_scores.get(c, 0.0) for c in valid_cids], dtype=np.float32)
    base_n = normalize_scores_minmax(base_raw)
    pred_n = normalize_scores_minmax(np.array(pred, dtype=np.float32))

    ra = float(rerank_alpha)
    final_scores = ra * base_n + (1.0 - ra) * pred_n
    order = np.argsort(-final_scores)
    reranked_valid = [valid_cids[int(i)] for i in order]

    # Preserve controls without reranker text (append in base order).
    reranked_full = reranked_valid + [c for c in cids_all if c in missing_text_set]

    if len(order) >= 2:
        fs1 = float(final_scores[int(order[0])])
        fs2 = float(final_scores[int(order[1])])
        rerank_margin_ratio = (fs1 - fs2) / max(fs1, 1e-9)
    else:
        rerank_margin_ratio = 1.0

    rerank_top1 = reranked_full[0] if reranked_full else ""

    # Adoption gate: if reranker changes top1 but with weak margin, keep base ordering.
    # Patch (rerankgate_v1): when the base fused ranking is low-confidence, relax the apply threshold modestly.
    rerank_applied = True
    final_ranked = reranked_full

    effective_apply_min = float(rerank_apply_min_margin_ratio)
    base_uncertain_thr = 0.08
    if float(base_margin_ratio) < float(base_uncertain_thr):
        effective_apply_min = min(effective_apply_min, 0.10)

    if (rerank_top1 != base_top1) and (rerank_margin_ratio < float(effective_apply_min)):
        rerank_applied = False
        final_ranked = cids_all

    final_top1 = final_ranked[0] if final_ranked else ""
    if rerank_applied:
        final_margin_ratio = float(rerank_margin_ratio)
    else:
        final_margin_ratio = float(base_margin_ratio)

    # Debug: capture fused vs rerank vs final details for the top candidates (no effect on ranking)
    debug_top: List[Dict[str, Any]] = []
    try:
        base_rank_map = {c: i + 1 for i, c in enumerate(cids_all)}
        rerank_rank_map = {c: i + 1 for i, c in enumerate(reranked_full)}
        final_rank_map = {c: i + 1 for i, c in enumerate(final_ranked)}
        lim = int(min(20, len(cids_all)))
        valid_idx_map = {c: i for i, c in enumerate(valid_cids)}
        for i in range(lim):
            cid = cids_all[i]
            v_idx = valid_idx_map.get(cid)
            debug_top.append(
                {
                    "control_id": cid,
                    "rrf_score": float(rrf_scores.get(cid, 0.0)),
                    "base_rank": int(base_rank_map.get(cid, 0)),
                    "rerank_rank": int(rerank_rank_map.get(cid, 0)),
                    "final_rank": int(final_rank_map.get(cid, 0)),
                    "base_score_norm": float(base_n[int(v_idx)]) if v_idx is not None and int(v_idx) < len(base_n) else None,
                    "rerank_score_raw": float(pred[int(v_idx)]) if v_idx is not None and int(v_idx) < len(pred) else None,
                    "rerank_score_norm": float(pred_n[int(v_idx)]) if v_idx is not None and int(v_idx) < len(pred_n) else None,
                    "final_score": float(final_scores[int(v_idx)]) if v_idx is not None and int(v_idx) < len(final_scores) else None,
                }
            )
    except Exception:
        debug_top = []

    meta = {
        "num_variants": len(variants),
        "top_candidates": debug_top,
        "reranker_called": True,
        "rerank_applied": rerank_applied,
        "skip_reason": None,
        "rerank_alpha": float(rerank_alpha),
        "rerank_apply_min_margin_ratio": float(rerank_apply_min_margin_ratio),
        "rerank_effective_apply_min_margin_ratio": float(effective_apply_min),
        "rerank_skip_min_base_margin_ratio": float(rerank_skip_min_base_margin_ratio),
        "rerank_skip_require_top1_agreement": bool(rerank_skip_require_top1_agreement),
        "base_top1": base_top1,
        "base_top2": base_top2,
        "base_margin_ratio": float(base_margin_ratio),
        "bm25_top1": bm25_top1 if bool(rerank_skip_require_top1_agreement) else None,
        "dense_top1": dense_top1 if bool(rerank_skip_require_top1_agreement) else None,
        "top1_agree": bool(top1_agree) if bool(rerank_skip_require_top1_agreement) else None,
        "rerank_top1": rerank_top1,
        "final_top1": final_top1,
        "rerank_margin_ratio": float(rerank_margin_ratio),
        "final_margin_ratio": float(final_margin_ratio),
        "scope_bias": scope_bias_meta,
    }
    return final_ranked, meta


# ==========================================================
# 7) Config + retriever (pipeline-facing)
# ==========================================================
@dataclass(frozen=True)
class RetrievalConfig:
    # CCS filtering
    keep_kinds: Tuple[str, ...] = ("smt", "gdn")

    # BM25 params: package-common defaults, not universal optima.
    bm25_k1: float = 1.5
    bm25_b: float = 0.75

    # Dense / rerank models
    dense_model_id: str = "intfloat/e5-small-v2"
    reranker_model_id: str = "BAAI/bge-reranker-base"

    # Ranking params: RRF k=60 is traceable to Cormack et al.; pool size is a
    # fixed project choice. See CONSTANTS_PROVENANCE.md for the full boundary.
    candidate_set_size: int = 50
    rrf_k: int = 60

    # Rewrite params
    max_rewrites: int = 3
    rewrite_weight: float = 0.25
    rewrite_jaccard_min: float = 0.15

    # Rerank blending + adoption gate
    rerank_alpha: float = 0.65
    rerank_apply_min_margin_ratio: float = 0.15

    # Pre-rerank skip gate (performance + accuracy)
    rerank_skip_enabled: bool = True
    rerank_skip_min_base_margin_ratio: float = 0.10
    rerank_skip_require_top1_agreement: bool = False

    # Evidence selection
    clauses_per_control: int = 12
    kind_priority: Tuple[str, ...] = ("smt", "gdn")  # fill missing evidence in this order

    # Evidence gating (keep params in CCS, but avoid citing them as evidence)
    evidence_kinds: Tuple[str, ...] = ("smt", "gdn")

    # Prefer more specific statement subclauses (e.g., *_smt.a) over top-level statements
    prefer_depth1_subclauses: bool = True

    # Retrieval-query planning (generic, demo-safe category improvements)
    strip_meta_instructions_for_retrieval: bool = True
    expand_scope_terms_for_retrieval: bool = True
    scope_match_bias_ratio: float = 0.08
    scope_mismatch_penalty_ratio: float = 0.06


class ComplianceGPTRetriever:
    """
    Pipeline-facing retriever.

    Canonical API (use these names everywhere):
      - __init__(ccs_path=..., config=RetrievalConfig())
      - retrieve(query, top_k=..., rewrites=...) -> list[doc_dict]
      - ids: clause ids (for pipeline CCS sanity checks)
    """

    def __init__(self, *, ccs_path: str, config: RetrievalConfig = RetrievalConfig(), **kwargs):
        self.config = config

        # 1) Load CCS
        #    - self.records: retrieval corpus (clause-only kinds)
        #    - self.record_by_id: full CCS inventory (includes odp/prm for canonicalization)
        self.records = load_clause_records_jsonl(ccs_path, keep_kinds=config.keep_kinds)
        self.record_by_id = load_all_records_by_id_jsonl(ccs_path)
        # Ensure clause records used in retrieval are stored in canonical, normalized form
        for r in self.records:
            self.record_by_id[r["id"]] = r

        # clause ids for CCS sanity check
        self.ids = [r["id"] for r in self.records]

        # 2) Build control->clauses maps (for evidence selection fallback)
        self.control_to_clause_ids: Dict[str, List[str]] = defaultdict(list)
        self.control_to_clause_ids_by_kind: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
        for r in self.records:
            ctl = normalize_control_id(r.get("control_id", "")).upper()
            if not ctl:
                continue
            self.control_to_clause_ids[ctl].append(r["id"])
            self.control_to_clause_ids_by_kind[ctl][str(r.get("kind", "other")).lower()].append(r["id"])

        # 3) BM25 on control-level aggregated docs
        ctl_docs = build_control_docs_from_clauses(self.records)
        self.bm25, self.bm25_control_ids = build_bm25(ctl_docs, k1=config.bm25_k1, b=config.bm25_b)

        # 4) Dense clause index + control adapter
        self.dense_adapter, self.clause_id_to_packed_text, self.clause_to_control, self.dense_index = build_dense_retriever(
            self.records, dense_model_id=config.dense_model_id
        )

        # 5) Reranker
        self.reranker = build_reranker(config.reranker_model_id)

        # 6) Control fallback text for reranker inputs
        self.reranker_text_by_control = build_control_fallback_text_map(self.records)

    def _prepare_retrieval_plan(self, query: str, rewrites: Any = None) -> Dict[str, Any]:
        raw_rewrites = _coerce_rewrite_list(rewrites)
        retrieval_query, query_meta = build_retrieval_query(
            query,
            strip_meta=bool(getattr(self.config, "strip_meta_instructions_for_retrieval", True)),
            expand_scope_terms=bool(getattr(self.config, "expand_scope_terms_for_retrieval", True)),
        )

        retrieval_rewrites: List[str] = []
        rewrite_debug: List[Dict[str, Any]] = []
        seen: Set[str] = set()
        if retrieval_query:
            seen.add(retrieval_query)

        for r in raw_rewrites:
            rr, rr_meta = build_retrieval_query(
                r,
                strip_meta=bool(getattr(self.config, "strip_meta_instructions_for_retrieval", True)),
                expand_scope_terms=bool(getattr(self.config, "expand_scope_terms_for_retrieval", True)),
            )
            rewrite_debug.append(rr_meta)
            if rr and rr not in seen:
                seen.add(rr)
                retrieval_rewrites.append(rr)

        variants = build_query_variants(
            retrieval_query,
            retrieval_rewrites,
            max_rewrites=self.config.max_rewrites,
            jaccard_min=self.config.rewrite_jaccard_min,
        )

        return {
            "raw_query": str(query or "").strip(),
            "retrieval_query": retrieval_query,
            "raw_rewrites": raw_rewrites,
            "retrieval_rewrites": retrieval_rewrites,
            "rewrites_debug": rewrite_debug,
            "query_meta": query_meta,
            "variants": variants,
            "query_scope": str((query_meta or {}).get("scope") or "neutral"),
        }

    def _select_clauses_for_controls(self, query: str, controls: List[str]) -> Dict[str, List[str]]:
        """
        Select up to `clauses_per_control` clause ids per control.

        Research-grade selection: purely semantic score from the dense index.
        No depth bucketing and no post-hoc kind-based inventory fill.
        """
        controls_set = set(controls)
        per_ctl: Dict[str, List[Tuple[str, float]]] = defaultdict(list)

        clause_hits = self.dense_index.search(query, top_k=max(100, self.config.candidate_set_size * 20))
        allowed_kinds = set(k.lower() for k in (self.config.evidence_kinds or ()))

        for clause_id, score in clause_hits:
            rec = self.record_by_id.get(clause_id)
            if not rec:
                continue
            kind = str(rec.get("kind", "")).lower()
            if allowed_kinds and kind not in allowed_kinds:
                continue

            ctl = normalize_control_id(self.clause_to_control.get(clause_id, "")).upper()
            if ctl not in controls_set:
                continue

            per_ctl[ctl].append((clause_id, float(score)))

        selected: Dict[str, List[str]] = {}
        for ctl in controls:
            hits = per_ctl.get(ctl, [])
            if hits:
                hits_sorted = sorted(hits, key=lambda x: x[1], reverse=True)

                # Take a modest per-control candidate pool, then optionally rerank within-control.
                # This helps distinguish closely-related leaf clauses (e.g., *.a vs *.b) without
                # injecting any unseen evidence.
                top_m = max(int(self.config.clauses_per_control) * 6, 24)
                cand = hits_sorted[:top_m]

                rerank_scores: Optional[Dict[str, float]] = None
                try:
                    pairs: List[Tuple[str, str]] = []
                    cand_ids: List[str] = []
                    for cid, _ds in cand:
                        rec2 = self.record_by_id.get(cid)
                        if not rec2:
                            continue
                        title2 = str(rec2.get("title", "") or "")
                        text2 = str(rec2.get("text", "") or "")
                        doc_text = (title2 + "\n" + text2).strip() if title2 else text2
                        if not doc_text:
                            continue
                        pairs.append((query, doc_text))
                        cand_ids.append(cid)

                    if pairs and cand_ids:
                        preds = self.reranker.predict(
                            pairs,
                            batch_size=32,
                            convert_to_numpy=True,
                            show_progress_bar=False,
                        )
                        rerank_scores = {cid: float(preds[i]) for i, cid in enumerate(cand_ids)}
                except Exception:
                    rerank_scores = None

                def _subclause_depth(clause_id: str) -> int:
                    # Depth after kind marker (e.g., "ac-2_smt.h.3" -> 2; "ac-11_smt" -> 0).
                    if "_" not in clause_id:
                        return 0
                    tail = clause_id.split("_", 1)[1]
                    if tail.startswith("smt"):
                        rest = tail[3:]
                    elif tail.startswith("gdn"):
                        rest = tail[3:]
                    else:
                        rest = ""
                    if rest.startswith("."):
                        rest = rest[1:]
                    if not rest:
                        return 0
                    return len(rest.split("."))

                scored: List[Tuple[str, float, int, int]] = []
                for cid, dense_score in cand:
                    rec2 = self.record_by_id.get(cid)
                    if not rec2:
                        continue
                    base = float(dense_score)
                    if rerank_scores and cid in rerank_scores:
                        base = float(rerank_scores[cid])
                    depth = _subclause_depth(cid) if self.config.prefer_depth1_subclauses else 0
                    text_len = len(str(rec2.get("text", "") or ""))
                    scored.append((cid, base, depth, text_len))

                scored_sorted = sorted(scored, key=lambda x: (x[1], x[2], x[3]), reverse=True)

                seen: Set[str] = set()
                best_ids: List[str] = []
                for cid, _s, _d, _tl in scored_sorted:
                    if cid in seen:
                        continue
                    best_ids.append(cid)
                    seen.add(cid)
                    if len(best_ids) >= int(self.config.clauses_per_control):
                        break

                selected[ctl] = best_ids
            else:
                selected[ctl] = []

        return selected

    def retrieve(self, query: str, top_k: int = 10, rewrites: Any = None, **kwargs) -> List[Dict[str, Any]]:
        """
        Returns clause-level doc dicts:
          {id, control_id, kind, title, text}

        - `top_k` is the number of top controls to return evidence for.
        - total returned docs ~= top_k * clauses_per_control (minus missing).
        """
        plan = self._prepare_retrieval_plan(query, rewrites)
        retrieval_query = str(plan.get("retrieval_query") or query)
        variants = list(plan.get("variants") or [retrieval_query])

        ranked_controls, _meta = s7_rank_controls(
            original_query=retrieval_query,
            variants=variants,
            bm25_retriever=self.bm25,
            bm25_control_ids=self.bm25_control_ids,
            dense_adapter=self.dense_adapter,
            reranker=self.reranker,
            reranker_text_by_control=self.reranker_text_by_control,
            candidate_set_size=self.config.candidate_set_size,
            rrf_k=self.config.rrf_k,
            rewrite_weight=self.config.rewrite_weight,
            rerank_alpha=self.config.rerank_alpha,
            rerank_apply_min_margin_ratio=self.config.rerank_apply_min_margin_ratio,
            rerank_skip_enabled=self.config.rerank_skip_enabled,
            rerank_skip_min_base_margin_ratio=self.config.rerank_skip_min_base_margin_ratio,
            rerank_skip_require_top1_agreement=self.config.rerank_skip_require_top1_agreement,
            query_scope=str(plan.get("query_scope") or "neutral"),
            scope_match_bias_ratio=float(getattr(self.config, "scope_match_bias_ratio", 0.08)),
            scope_mismatch_penalty_ratio=float(getattr(self.config, "scope_mismatch_penalty_ratio", 0.06)),
        )

        # Expose last retrieval diagnostics for pipeline-level debugging (no effect on ranking)
        try:
            self.last_meta = dict(_meta or {})
            self.last_meta["query_transform"] = {
                "raw_query": plan.get("raw_query"),
                "retrieval_query": retrieval_query,
                "raw_rewrites": list(plan.get("raw_rewrites") or []),
                "retrieval_rewrites": list(plan.get("retrieval_rewrites") or []),
                "query_scope": plan.get("query_scope"),
                "query_meta": dict(plan.get("query_meta") or {}),
            }
            self.last_ranked_controls = list(ranked_controls or [])
            self.last_variants = list(variants or [])
        except Exception:
            self.last_meta = {}
            self.last_ranked_controls = []
            self.last_variants = list(variants or [])

        controls = [normalize_control_id(c).upper() for c in ranked_controls][: int(top_k)]
        if not controls:
            return []

        ctl_to_clause_ids = self._select_clauses_for_controls(retrieval_query, controls)

        docs: List[Dict[str, Any]] = []
        for ctl in controls:
            for clause_id in ctl_to_clause_ids.get(ctl, []):
                rec = self.record_by_id.get(clause_id)
                if not rec:
                    continue
                docs.append(
                    {
                        "id": rec["id"],
                        "control_id": normalize_control_id(rec.get("control_id", "")),
                        "kind": rec.get("kind", "other"),
                        "title": rec.get("title", ""),
                        "text": rec.get("text", ""),
                    }
                )

        return docs

    def retrieve_debug(self, query: str, top_k: int = 10, rewrites: Any = None, **kwargs) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Debug-friendly retrieval.

        Returns:
          (docs, meta)

        - docs: same as `retrieve()`
        - meta: includes ranking diagnostics (control ranking + rerank gate info) and how clauses were selected.
        """
        plan = self._prepare_retrieval_plan(query, rewrites)
        retrieval_query = str(plan.get("retrieval_query") or query)
        variants = list(plan.get("variants") or [retrieval_query])

        ranked_controls, meta = s7_rank_controls(
            original_query=retrieval_query,
            variants=variants,
            bm25_retriever=self.bm25,
            bm25_control_ids=self.bm25_control_ids,
            dense_adapter=self.dense_adapter,
            reranker=self.reranker,
            reranker_text_by_control=self.reranker_text_by_control,
            candidate_set_size=self.config.candidate_set_size,
            rrf_k=self.config.rrf_k,
            rewrite_weight=self.config.rewrite_weight,
            rerank_alpha=self.config.rerank_alpha,
            rerank_apply_min_margin_ratio=self.config.rerank_apply_min_margin_ratio,
            rerank_skip_enabled=self.config.rerank_skip_enabled,
            rerank_skip_min_base_margin_ratio=self.config.rerank_skip_min_base_margin_ratio,
            rerank_skip_require_top1_agreement=self.config.rerank_skip_require_top1_agreement,
            query_scope=str(plan.get("query_scope") or "neutral"),
            scope_match_bias_ratio=float(getattr(self.config, "scope_match_bias_ratio", 0.08)),
            scope_mismatch_penalty_ratio=float(getattr(self.config, "scope_mismatch_penalty_ratio", 0.06)),
        )

        controls = [normalize_control_id(c).upper() for c in ranked_controls][: int(top_k)]
        if not controls:
            meta = dict(meta or {})
            meta.update({"variants": variants, "ranked_controls": ranked_controls, "selected_controls": []})
            return [], meta

        ctl_to_clause_ids = self._select_clauses_for_controls(retrieval_query, controls)

        docs: List[Dict[str, Any]] = []
        for ctl in controls:
            for clause_id in ctl_to_clause_ids.get(ctl, []):
                rec = self.record_by_id.get(clause_id)
                if not rec:
                    continue
                docs.append(
                    {
                        "id": rec["id"],
                        "control_id": normalize_control_id(rec.get("control_id", "")),
                        "kind": rec.get("kind", "other"),
                        "title": rec.get("title", ""),
                        "text": rec.get("text", ""),
                    }
                )

        meta = dict(meta or {})
        meta["query_transform"] = {
            "raw_query": plan.get("raw_query"),
            "retrieval_query": retrieval_query,
            "raw_rewrites": list(plan.get("raw_rewrites") or []),
            "retrieval_rewrites": list(plan.get("retrieval_rewrites") or []),
            "query_scope": plan.get("query_scope"),
            "query_meta": dict(plan.get("query_meta") or {}),
        }
        meta.update(
            {
                "variants": variants,
                "ranked_controls": ranked_controls,
                "selected_controls": controls,
                "selected_clause_ids_by_control": {k: list(v) for k, v in (ctl_to_clause_ids or {}).items()},
                "n_docs": len(docs),
            }
        )
        return docs, meta
