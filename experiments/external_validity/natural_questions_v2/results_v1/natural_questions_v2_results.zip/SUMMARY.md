# Separate natural-question results

Questions: 20. Paired outputs: 40.

These are author-reference coverage and contract outcomes. Independent correctness and the full responsiveness of partial/outside questions have not been assessed.

| Answer path | Runtime validity | Strict full-catalog contract | ODP sensitivity | ODP specificity |
|---|---:|---:|---:|---:|
| compliancegpt | 20/20 | 0/3 | 2/2 | 1/13 |
| generative_baseline | 13/20 | 0/3 | 0/2 | 13/13 |

## Limits

- One-forum purposive convenience sample. It does not estimate population-wide performance.
- Wilson intervals describe the eligible observed rows under a binomial assumption. They do not account for purposive source selection or correlated forum users.
- Original post captures include source control quotations and explicit IDs. Their presence is documented.
- Author-reviewed labels are reference judgments, not independent professional correctness.
- Full-text coverage is a conservative contract/evidence criterion and does not prove responsive semantic interpretation.
- Partial, outside and ambiguous questions remain visible. They are not counted as successful whole-question answers.
- Untestable ODP cases are not negative labels. Additional listed IDs are unadjudicated expansions.
- Answer-length and clarification counts are burden proxies, not measured user effort.
- Nonsignificant paired results do not establish equivalence.
